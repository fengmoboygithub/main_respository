---
home: true
heroImage: /images/logo.png
actionText: 快速开始 →
actionLink: /ruoyi/
features:
  - title: 最新技术栈
    details: 使用最流行的技术SpringBoot、Shiro、Thymeleaf、Vue、Bootstrap。
  - title: 前后端分离
    details: 提供前端Vue、后端Spring Boot完全分离的权限管理系统。
  - title: 代码生成器
    details: 在线配置表信息生成对应的代码，增删改查/排序/导出/权限控制等直接使用。
  - title: 简单快捷
    details: 基于SpringBoot的权限管理系统 易读易懂、界面简洁美观。
  - title: 功能完善
    details: 内置用户、部门、权限、字典、参数、监控、代码生成等基础功能。
  - title: 完全响应式布局
    details: 支持电脑、平板、手机等所有主流设备，提供多种不同风格的皮肤。
footer: MIT Licensed | Copyright © 2018-2019 ruoyi.vip All Rights Reserved 若依
---