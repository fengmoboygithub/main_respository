package com.company.two.joblog.dao;

import com.company.base.dao.IBaseDao;
import com.company.two.joblog.model.JobLogTab;
import com.company.two.joblog.model.JobLogTabExample;
public interface JobLogTabMapper extends IBaseDao<JobLogTab, JobLogTabExample>{

}