package com.company.one.agencyinfo.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.agencyinfo.model.AgencyInfo;
import com.company.one.agencyinfo.model.AgencyInfoExample;
public interface AgencyInfoMapper extends IBaseDao<AgencyInfo, AgencyInfoExample>{

}