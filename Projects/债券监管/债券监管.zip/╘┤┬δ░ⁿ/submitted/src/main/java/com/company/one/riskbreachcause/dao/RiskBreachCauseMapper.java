package com.company.one.riskbreachcause.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.riskbreachcause.model.RiskBreachCause;
import com.company.one.riskbreachcause.model.RiskBreachCauseExample;
public interface RiskBreachCauseMapper extends IBaseDao<RiskBreachCause, RiskBreachCauseExample>{

}