package com.company.one.baseinfo.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.baseinfo.model.BondBaseInfo;
import com.company.one.baseinfo.model.BondBaseInfoExample;
public interface BondBaseInfoMapper extends IBaseDao<BondBaseInfo, BondBaseInfoExample>{

}