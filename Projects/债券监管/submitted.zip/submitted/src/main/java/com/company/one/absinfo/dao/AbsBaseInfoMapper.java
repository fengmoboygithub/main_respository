package com.company.one.absinfo.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.absinfo.model.AbsBaseInfo;
import com.company.one.absinfo.model.AbsBaseInfoExample;
public interface AbsBaseInfoMapper extends IBaseDao<AbsBaseInfo, AbsBaseInfoExample>{

}