package com.company.one.publisherinfo.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.publisherinfo.model.PublisherInfo;
import com.company.one.publisherinfo.model.PublisherInfoExample;
public interface PublisherInfoMapper extends IBaseDao<PublisherInfo, PublisherInfoExample>{

}