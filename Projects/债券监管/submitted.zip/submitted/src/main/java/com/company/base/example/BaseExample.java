package com.company.base.example;
import java.io.Serializable;



/**
 * @author yangyanchao
 *
 */
public class BaseExample implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8854172171163880901L;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}