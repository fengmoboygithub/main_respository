import Vue from 'vue'

export default Vue.extend({
  name: 'TestTsFile',

  render(h) {
    return h('span', 'test .ts file')
  },
})
