{{ message }}

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class TsInMd extends Vue {
  message = 'TypeScript in Markdown'
}
</script>
