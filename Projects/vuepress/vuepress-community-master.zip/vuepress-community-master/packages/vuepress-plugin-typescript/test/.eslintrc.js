module.exports = {
  overrides: [
    {
      files: ['./**/*.vue'],
      extends: 'vuepress-typescript',
    },
  ],
}
