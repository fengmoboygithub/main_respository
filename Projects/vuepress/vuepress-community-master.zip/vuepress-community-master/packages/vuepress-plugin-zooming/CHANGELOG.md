# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.8](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-zooming@1.1.7...vuepress-plugin-zooming@1.1.8) (2020-09-01)

**Note:** Version bump only for package vuepress-plugin-zooming

## [1.1.7](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-zooming@1.1.6...vuepress-plugin-zooming@1.1.7) (2019-11-29)

**Note:** Version bump only for package vuepress-plugin-zooming

## [1.1.6](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-zooming@1.1.5...vuepress-plugin-zooming@1.1.6) (2019-11-20)

**Note:** Version bump only for package vuepress-plugin-zooming

## [1.1.5](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-zooming@1.1.3...vuepress-plugin-zooming@1.1.5) (2019-10-18)

### Bug Fixes

- **vuepress-plugin-zooming:** add options type ([01e0c2b](https://github.com/vuepress/vuepress-community/commit/01e0c2bcfffe8f0832611df3f154868fa1655611))

## 1.1.3 (2019-10-12)

### Bug Fixes

- **vuepress-plugin-zooming:** update types ([9ec57c5](https://github.com/vuepress/vuepress-community/commit/9ec57c5))
