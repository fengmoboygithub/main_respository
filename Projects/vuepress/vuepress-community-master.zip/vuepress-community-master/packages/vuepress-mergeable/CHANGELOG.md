# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.4](https://github.com/vuepress/vuepress-community/compare/vuepress-mergeable@1.1.3...vuepress-mergeable@1.1.4) (2020-09-01)

**Note:** Version bump only for package vuepress-mergeable

## [1.1.3](https://github.com/vuepress/vuepress-community/compare/vuepress-mergeable@1.1.2...vuepress-mergeable@1.1.3) (2019-12-27)

### Bug Fixes

- **mergeable:** add plugin-api param ([a96ef12](https://github.com/vuepress/vuepress-community/commit/a96ef12a69d48412c6adf624b86f615e954707fb))

## [1.1.2](https://github.com/vuepress/vuepress-community/compare/vuepress-mergeable@1.1.1...vuepress-mergeable@1.1.2) (2019-11-29)

**Note:** Version bump only for package vuepress-mergeable

## [1.1.1](https://github.com/vuepress/vuepress-community/compare/vuepress-mergeable@1.1.0...vuepress-mergeable@1.1.1) (2019-11-20)

**Note:** Version bump only for package vuepress-mergeable

# 1.1.0 (2019-10-18)

### Features

- **vuepress-mergeable:** migrate with types ([6e3f980](https://github.com/vuepress/vuepress-community/commit/6e3f980ae01653534c6fe6c25e72f7be6dc3b161))
