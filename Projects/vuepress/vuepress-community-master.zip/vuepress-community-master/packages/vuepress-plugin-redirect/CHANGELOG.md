# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.2.5](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-redirect@1.2.4...vuepress-plugin-redirect@1.2.5) (2020-09-01)

**Note:** Version bump only for package vuepress-plugin-redirect

## [1.2.4](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-redirect@1.2.3...vuepress-plugin-redirect@1.2.4) (2020-05-21)

**Note:** Version bump only for package vuepress-plugin-redirect

## [1.2.3](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-redirect@1.2.2...vuepress-plugin-redirect@1.2.3) (2020-02-03)

**Note:** Version bump only for package vuepress-plugin-redirect

## [1.2.2](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-redirect@1.2.1...vuepress-plugin-redirect@1.2.2) (2020-01-03)

**Note:** Version bump only for package vuepress-plugin-redirect

## [1.2.1](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-redirect@1.2.0...vuepress-plugin-redirect@1.2.1) (2019-11-29)

### Bug Fixes

- **plugin-redirect:** window is undefined error in build mode ([5388fc7](https://github.com/vuepress/vuepress-community/commit/5388fc7e115d2f8935cd696ce9c864f086b8d379))

# 1.2.0 (2019-11-20)

### Features

- **vuepress-plugin-redirect:** migrate with types ([54990e1](https://github.com/vuepress/vuepress-community/commit/54990e1e47e642ce3db304a2eb1d6cb4aab44cf7))
