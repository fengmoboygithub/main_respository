import { PluginOptionAPI } from './plugin'

export interface ThemeOptionAPI extends PluginOptionAPI {
  extend?: string
}
