# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.9](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-medium-zoom@1.1.8...vuepress-plugin-medium-zoom@1.1.9) (2020-09-01)

**Note:** Version bump only for package vuepress-plugin-medium-zoom

## [1.1.8](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-medium-zoom@1.1.7...vuepress-plugin-medium-zoom@1.1.8) (2019-11-29)

**Note:** Version bump only for package vuepress-plugin-medium-zoom

## [1.1.7](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-medium-zoom@1.1.6...vuepress-plugin-medium-zoom@1.1.7) (2019-11-20)

**Note:** Version bump only for package vuepress-plugin-medium-zoom

## [1.1.6](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-medium-zoom@1.1.4...vuepress-plugin-medium-zoom@1.1.6) (2019-10-18)

### Bug Fixes

- **vuepress-plugin-medium-zoom:** add options type ([e196a0b](https://github.com/vuepress/vuepress-community/commit/e196a0ba2716b287699c91bab488e6ac77356646))

## 1.1.4 (2019-10-12)

### Bug Fixes

- **vuepress-plugin-medium-zoom:** update types ([e068456](https://github.com/vuepress/vuepress-community/commit/e068456))
