# vuepress-plugin-medium-zoom

> VuePress plugin for medium-zoom

## Documentation

[vuepress.github.io](https://vuepress.github.io)

## License

[MIT](https://github.com/vuepress/vuepress-community/blob/master/LICENSE) &copy; [VuePress Community](https://github.com/vuepress)
