# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.8](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-nprogress@1.1.7...vuepress-plugin-nprogress@1.1.8) (2020-09-01)

**Note:** Version bump only for package vuepress-plugin-nprogress

## [1.1.7](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-nprogress@1.1.6...vuepress-plugin-nprogress@1.1.7) (2020-05-21)

**Note:** Version bump only for package vuepress-plugin-nprogress

## [1.1.6](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-nprogress@1.1.5...vuepress-plugin-nprogress@1.1.6) (2019-11-29)

**Note:** Version bump only for package vuepress-plugin-nprogress

## [1.1.5](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-nprogress@1.1.4...vuepress-plugin-nprogress@1.1.5) (2019-11-20)

**Note:** Version bump only for package vuepress-plugin-nprogress

## [1.1.4](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-nprogress@1.1.2...vuepress-plugin-nprogress@1.1.4) (2019-10-18)

**Note:** Version bump only for package vuepress-plugin-nprogress

## 1.1.2 (2019-10-12)

**Note:** Version bump only for package vuepress-plugin-nprogress
