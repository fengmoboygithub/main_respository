# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.2](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-clean-urls@1.1.1...vuepress-plugin-clean-urls@1.1.2) (2020-09-01)

**Note:** Version bump only for package vuepress-plugin-clean-urls

## [1.1.1](https://github.com/vuepress/vuepress-community/compare/vuepress-plugin-clean-urls@1.1.0...vuepress-plugin-clean-urls@1.1.1) (2019-11-29)

**Note:** Version bump only for package vuepress-plugin-clean-urls

# 1.1.0 (2019-11-20)

### Features

- **vuepress-plugin-clean-urls:** migrate with types ([dcae684](https://github.com/vuepress/vuepress-community/commit/dcae6848542dcd002ba0cdf6099fbbc3cb771c52))
