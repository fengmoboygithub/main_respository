<p align="center">
  <a href="https://vuepress.github.io/" target="_blank">
    <img width="180" src="https://raw.githubusercontent.com/vuepress/vuepress-community/master/packages/docs/src/.vuepress/public/logo/600x600.png" alt="logo">
  </a>
</p>

<h2 align="center">
  VuePress Community
</h2>

<p align="center">
  <a href="https://circleci.com/gh/vuepress/workflows/vuepress-community" target="_blank">
    <img src="https://badgen.net/circleci/github/vuepress/vuepress-community/master?icon=circleci">
  </a>

  <a href="https://travis-ci.com/vuepress/vuepress-community" target="_blank">
    <img src="https://badgen.net/travis/vuepress/vuepress-community?label=docs&icon=travis">
  </a>

  <a href="https://github.com/vuepress/vuepress-community/commits" target="_blank">
    <img src="https://badgen.net/github/last-commit/vuepress/vuepress-community?icon=github">
  </a>
  
  <a href="https://github.com/vuepress/vuepress-community/blob/master/LICENSE" target="_blank">
    <img src="https://badgen.net/github/license/vuepress/vuepress-community">
  </a>
</p>

<p align="center">
  Community supported ecosystem for <a href="https://github.com/vuejs/vuepress" target="_blank">VuePress</a>
</p>

## Documentation

[vuepress.github.io](https://vuepress.github.io)

## License

[MIT](https://github.com/vuepress/vuepress-community/blob/master/LICENSE) &copy; [VuePress Community](https://github.com/vuepress)
