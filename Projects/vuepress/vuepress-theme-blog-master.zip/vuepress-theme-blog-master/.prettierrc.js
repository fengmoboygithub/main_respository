module.exports = {
  semi:false,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'es5',
}
