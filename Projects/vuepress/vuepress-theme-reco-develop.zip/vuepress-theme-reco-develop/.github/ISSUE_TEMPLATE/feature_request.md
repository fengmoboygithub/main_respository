---
name: Feature request
about: Suggest an idea for this project
---

## Feature request

#### What problem does this feature solve?


#### How should this be implemented in your opinion?


#### Are you willing to work on this yourself?
