# @vuepress-reco/vuepress-plugin-loading-page

## Details

> Loading page plugin for vuepress-theme-reco or other vuepress theme.

|使用位置|值|
|-|-|
|plugin name|@vuepress-reco/vuepress-plugin-loading-page|
|component name|LoadingPage（主题开发时使用）|


