export default {
  homeBlog: {
    article: '글',
    tag: '태그',
    category: '분류',
    friendLink: '링크 참조'
  },
  tag: {
    all: '전체'
  }
}
