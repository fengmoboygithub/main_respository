export default {
  homeBlog: {
    article: '文章',
    tag: '標簽',
    category: '分類',
    friendLink: '友情鏈接'
  },
  tag: {
    all: '全部'
  }
}
