export default {
  homeBlog: {
    article: 'Article',
    tag: 'Tag',
    category: 'Category',
    friendLink: 'Friend Link'
  },
  tag: {
    all: 'All'
  }
}
