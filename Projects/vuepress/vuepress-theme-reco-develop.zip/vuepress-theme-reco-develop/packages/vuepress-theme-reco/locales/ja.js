export default {
  homeBlog: {
    article: '文章',
    tag: 'ラベル',
    category: '分類',
    friendLink: '友情リンク'
  },
  tag: {
    all: '全部'
  }
}
