export default {
  homeBlog: {
    article: '文章',
    tag: '标签',
    category: '分类',
    friendLink: '友情链接'
  },
  tag: {
    all: '全部'
  }
}
