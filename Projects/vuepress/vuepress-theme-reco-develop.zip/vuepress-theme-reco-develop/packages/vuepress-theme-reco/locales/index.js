import zhHans from './zh-hans.js'
import zhHant from './zh-hant.js'
import en from './en.js'
import ja from './ja.js'
import ko from './ko.js'

export { zhHans, zhHant, en, ja, ko }
