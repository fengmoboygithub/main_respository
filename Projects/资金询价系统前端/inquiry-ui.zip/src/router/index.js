import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: 路由配置项
 *
 * hidden: true                   // 当设置 true 的时候该路由不会再侧边栏出现 如401，login等页面，或者如一些编辑页面/edit/1
 * alwaysShow: true               // 当你一个路由下面的 children 声明的路由大于1个时，自动会变成嵌套的模式--如组件页面
 *                                // 只有一个时，会将那个子路由当做根路由显示在侧边栏--如引导页面
 *                                // 若你想不管路由下面的 children 声明的个数都显示你的根路由
 *                                // 你可以设置 alwaysShow: true，这样它就会忽略之前定义的规则，一直显示根路由
 * redirect: noRedirect           // 当设置 noRedirect 的时候该路由在面包屑导航中不可被点击
 * name:'router-name'             // 设定路由的名字，一定要填写不然使用<keep-alive>时会出现各种问题
 * meta : {
    roles: ['admin','editor']    // 设置该路由进入的权限，支持多个权限叠加
    title: 'title'               // 设置该路由在侧边栏和面包屑中展示的名字
    icon: 'svg-name'             // 设置该路由的图标，对应路径src/icons/svg
    breadcrumb: false            // 如果设置为false，则不会在breadcrumb面包屑中显示
  }
 */

// 公共路由
export const constantRoutes = [
  {
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path(.*)',
        component: (resolve) => require(['@/views/redirect'], resolve)
      }
    ]
  },
  {
    path: '/login',
    component: (resolve) => require(['@/views/login'], resolve),
    hidden: true
  },
  {
    path: '/404',
    component: (resolve) => require(['@/views/error/404'], resolve),
    hidden: true
  },
  {
    path: '/401',
    component: (resolve) => require(['@/views/error/401'], resolve),
    hidden: true
  },
  {
    path: '',
    component: Layout,
    redirect: 'index',
    children: [
      {
        path: 'index',
        component: (resolve) => require(['@/views/index'], resolve),
        name: '首页',
        meta: { title: '首页', icon: 'dashboard', noCache: true, affix: true }
      }
    ]
  },
  {
    path: '/user',
    component: Layout,
    hidden: true,
    redirect: 'noredirect',
    children: [
      {
        path: 'profile',
        component: (resolve) => require(['@/views/system/user/profile/index'], resolve),
        name: 'Profile',
        meta: { title: '个人中心', icon: 'user' }
      }
    ]
  },
  {
    path: '/dict',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'type/data/:dictId(\\d+)',
        component: (resolve) => require(['@/views/system/dict/data'], resolve),
        name: 'Data',
        meta: { title: '字典数据', icon: '' }
      }
    ]
  },
  {
    path: '/job',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'log',
        component: (resolve) => require(['@/views/monitor/job/log'], resolve),
        name: 'JobLog',
        meta: { title: '调度日志' }
      }
    ]
  },
  {
    path: '/gen',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'edit',
        component: (resolve) => require(['@/views/tool/gen/editTable'], resolve),
        name: 'GenEdit',
        meta: { title: '修改生成配置' }
      }
    ]
  },
  {
    path: '/deposit',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'edit',
        component: (resolve) => require(['@/views/business/deposit/edit'], resolve),
        name: 'DepositEdit',
        meta: { title: "编辑询价函" }
      },
      {
        path: 'add',
        component: (resolve) => require(['@/views/business/deposit/edit'], resolve),
        name: 'DepositAdd',
        meta: { title: "新增询价函" }
      },
      {
        path: 'query',
        component: (resolve) => require(['@/views/business/deposit/view'], resolve),
        name: 'DepositView',
        meta: { title: "询价函详情" }
      },
      {
        path: 'check',
        component: (resolve) => require(['@/views/business/deposit/view'], resolve),
        name: 'DepositCheck',
        meta: { title: "审核询价函" }
      },
      {
        path: 'cancel',
        component: (resolve) => require(['@/views/business/deposit/view'], resolve),
        name: 'DepositCancel',
        meta: { title: "取消询价函" }
      }
    ]
  },
  {
    path: '/loan',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'edit',
        component: (resolve) => require(['@/views/business/loan/edit'], resolve),
        name: 'LoanEdit',
        meta: { title: "编辑询价函" }
      },
      {
        path: 'add',
        component: (resolve) => require(['@/views/business/loan/edit'], resolve),
        name: 'LoanAdd',
        meta: { title: "新增询价函" }
      },
      {
        path: 'query',
        component: (resolve) => require(['@/views/business/loan/view'], resolve),
        name: 'LoanView',
        meta: { title: "询价函详情" }
      },
      {
        path: 'check',
        component: (resolve) => require(['@/views/business/loan/view'], resolve),
        name: 'LoanCheck',
        meta: { title: "审核询价函" }
      },
      {
        path: 'cancel',
        component: (resolve) => require(['@/views/business/loan/view'], resolve),
        name: 'LoanCancel',
        meta: { title: "取消询价函" }
      }
    ]
  },
  {
    path: '/loan_offer',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'detail',
        component: (resolve) => require(['@/views/business/loan_offer/editLoanOffer'], resolve),
        name: 'loan_offer_view_detail',
        meta: { title: '查看报价函信息-借款' }
      },
      {
        path: 'edit',
        component: (resolve) => require(['@/views/business/loan_offer/editLoanOffer'], resolve),
        name: 'loan_offer_view_edit',
        meta: { title: '修改报价函信息-借款' }
      },


      {
        path: 'allocationResult',
        component: (resolve) => require(['@/views/business/loan_offer/allocationResult'], resolve),
        name: 'loan_allocation_result_view',
        meta: { title: '借款报价分配结果' }
      }
    ]
  },
  {
    path: '/deposit_offer',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'edit',
        component: (resolve) => require(['@/views/business/deposit_offer/editTable'], resolve),
        name: 'deposit_offer_view_edit',
        meta: { title: '修改报价函信息-存款' }
      },
      {
        path: 'detail',
        component: (resolve) => require(['@/views/business/deposit_offer/editTable'], resolve),
        name: 'deposit_offer_view_detail',
        meta: { title: '报价函信息-存款详情' }
      },
      {
        path: 'allocationResult',
        component: (resolve) => require(['@/views/business/deposit_offer/allocationResult'], resolve),
        name: 'deposit_allocation_result_view',
        meta: { title: "存款报价分配结果" }
      }
    ]
  },

  {
    path: '/audit',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'query',
        component: (resolve) => require(['@/views/business/deposit/view'], resolve),
        name: 'DepositView',
        meta: { title: "询价函详情" }
      },
      {
        path: 'result',
        component: (resolve) => require(['@/views/business/operation_inquiry/viewResult'], resolve),
        name: 'DepositViewOver',
        meta: { title: "报价中结果" }
      },
      {
        path: 'view',
        component: (resolve) => require(['@/views/business/deposit_offer/editTable'], resolve),
        name: 'GenEdit',
        meta: { title: '报价函信息-存款' }
      },
      {
        path: 'Statistics',
        component: (resolve) => require(['@/views/business/operation_inquiry/viewStatistics'], resolve),
        name: 'ViewDepositStatistics',
        meta: { title: '报价结果统计' }
      },
      {
        path: 'distribution',
        component: (resolve) => require(['@/views/business/operation_inquiry/viewDistribution'], resolve),
        name: 'ViewDistribution',
        meta: { title: '分配结果' }
      }
    ]
  },
  {
    path: '/audit_loan',
    component: Layout,
    hidden: true,
    children: [
      {
        path: 'result',
        component: (resolve) => require(['@/views/business/operation_inquiry/loan/viewResult'], resolve),
        name: 'DepositViewOver',
        meta: { title: "报价中结果" }
      },
      {
        path: 'Statistics',
        component: (resolve) => require(['@/views/business/operation_inquiry/loan/viewStatistics'], resolve),
        name: 'ViewDepositStatistics',
        meta: { title: '报价结果统计' }
      },
      {
        path: 'distribution',
        component: (resolve) => require(['@/views/business/operation_inquiry/loan/viewDistribution'], resolve),
        name: 'ViewDistribution',
        meta: { title: '分配结果' }
      }
    ]
  }
]

export default new Router({
  mode: 'history', // 去掉url中的#
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})
