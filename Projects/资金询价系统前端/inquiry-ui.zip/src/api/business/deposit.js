
import request from '@/utils/request'
import {praseStrEmpty} from "@/utils/inquiry";

// 查询询价函列表
export function listDeposit(query) {
  return request({
    url: '/business/deposit/list',
    method: 'get',
    params: query
  })
}

// 查询询价函详细
export function getDeposit(id) {
  return request({
    url: '/business/deposit/' + praseStrEmpty(id),
    method: 'get'
  })
}

// 查询借款询价函详细
// export function getLoan(id) {
//   return request({
//     url: '/business/loan/' + praseStrEmpty(id),
//     method: 'get'
//   })
// }

// 查询存款询价函手机短信模板信息
export function getMobileMessage() {
  return request({
    url: '/common/constant/message',
    method: 'get'
  })
}

// 查询银行列表
export function listBanks() {
  return request({
    url: '/system/user/bank/list',
    method: 'get'
  })
}

// 新增询价函
export function addDeposit(data) {
  return request({
    url: '/business/deposit',
    method: 'post',
    data: data
  })
}

// 修改询价函
export function updateDeposit(data) {
  return request({
    url: '/business/deposit',
    method: 'put',
    data: data
  })
}

// 删除询价函
export function delDeposit(depositIds,inquiryNo) {
  return request({
    url: '/business/deposit',
    method: 'delete',
    params: {ids: depositIds, inquiryNo: inquiryNo}
  })
}

// 审核询价函
export function checkDeposit(id, status,inquiryNo) {
  const data = {
    id,
    status,
    inquiryNo
  }
  return request({
    url: '/business/deposit/check',
    method: 'put',
    data: data
  })
}


// 撤回询价函
export function withdrawDeposit(id, inquiryNo) {
  const data = {
    id,
    inquiryNo
  }
  return request({
    url: '/business/deposit/withdraw',
    method: 'put',
    data: data
  })
}

// 取消询价函
export function cancelDeposit(id, remark, status, inquiryNo) {
  const data = {
    id,
    remark,
    status,
    inquiryNo
  }
  return request({
    url: '/business/deposit/cancel',
    method: 'put',
    data: data
  })
}

// 查询询价关联的存款报价列表
export function depositOfferList(query) {
  return request({
    url: '/business/deposit/depositOfferList',
    method: 'get',
    params: query
  })
}

// 查询询价关联的借款报价列表
// export function loanOfferList(query) {
//   return request({
//     url: '/business/loan/loanOfferList',
//     method: 'get',
//     params: query
//   })
// }

// 查询询价关联的报价列表
export function calculateDepositDueTime(dt, lt, lu) {
  return request({
    url: '/business/deposit/due',
    method: 'get',
    params: {date: dt, limit: lt, unit: lu}
  })
}

