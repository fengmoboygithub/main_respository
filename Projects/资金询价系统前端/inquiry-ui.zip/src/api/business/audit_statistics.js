import request from '@/utils/request'

// 查询询价函存款审计列表
export function removeDeafList(query) {
  return request({
    url: '/business/statistics/removeDeafList',
    method: 'get',
    params: query
  })
}

//获取存款询价信息
export function selectSysInquiryDepositById(id) {
  return request({
    url: '/business/statistics/selectSysInquiryDeposit/'+id,
    method: 'get',
  })
}

// 获取存款报价统计列表
export function auditStatisticsList(inquiryId) {
  return request({
    url: '/business/statistics/'+ inquiryId,
    method: 'get',
  })
}

//询价存款分配
export function distribution(id,amount,status) {
  const query = {
    id,
    amount,
    status
  }
  return request({
    url: '/business/statistics/distribution',
    method: 'get',
    params: query
  })
}

//导出存款报价统计列表列表
export function exportInquiryDeposit(id) {
  return request({
    url: '/business/statistics/exportInquiryDeposit/'+id,
    method: 'get',
  })
}

// 导出存款分配统计列表
export function exportDistribution(data) {
  return request({
    url: '/business/statistics/exportDistribution',
    method: 'post',
    data: data
  })
}

//分配完成
export function assignSendData(list,id,inquiryNo) {
  const query = {
    id,
    inquiryNo
  }
  return request({
    url: '/business/statistics/assignSendData',
    method: 'post',
    data: list,
    params: query
  })
}

///////////////////////////////////////////借款/////////////////////////////////////

// 查询询价函借款审计列表
export function removeDeafLoanList(query) {
  return request({
    url: '/business/statistics/removeDeafLoanList',
    method: 'get',
    params: query
  })
}

//获取借款询价信息
export function selectSysInquiryLoanById(id) {
  return request({
    url: '/business/statistics/selectSysInquiryLoan/'+id,
    method: 'get',
  })
}

// 获取借款报价统计列表
export function auditStatisticsLoanList(inquiryId) {
  return request({
    url: '/business/statistics/Loan/'+ inquiryId,
    method: 'get',
  })
}

// 获取借款报价统计列表（分期限）
export function auditStatisticsLoanTermList(inquiryId) {
  return request({
    url: '/business/statistics/LoanTerm/'+ inquiryId,
    method: 'get',
  })
}

// 获取借款分配选项
export function listDistribution(inquiryId) {
  return request({
    url: '/business/statistics/listDistribution/'+ inquiryId,
    method: 'get',
  })
}

//询价借款分配
export function distributionLoan(id,amount,limitTime,status) {
  const query = {
    id,
    amount,
    limitTime,
    status
  }
  return request({
    url: '/business/statistics/distributionLoan',
    method: 'get',
    params: query
  })
}

//导出存款报价统计列表列表
export function exportInquiryLoan(id) {
  return request({
    url: '/business/statistics/exportInquiryLoan/'+id,
    method: 'get',
  })
}

//分配完成
export function assignSendDataLoan(list,id,assign,inquiryNo) {
  const query = {
    id,
    assign,
    inquiryNo
  }
  return request({
    url: '/business/statistics/assignSendDataLoan',
    method: 'post',
    data: list,
    params: query
  })
}
