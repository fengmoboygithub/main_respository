import request from '@/utils/request'

// 查询报价函信息-存款列表
export function listDeposit_offer(query) {
  return request({
    url: '/business/deposit_offer/list',
    method: 'get',
    params: query
  })
}

// 查询报价函信息-存款详细
export function getDeposit_offer(id) {
  return request({
    url: '/business/deposit_offer/' + id,
    method: 'get'
  })
}

// 新增报价函信息-存款
export function addDeposit_offer(data) {
  return request({
    url: '/business/deposit_offer',
    method: 'post',
    data: data
  })
}

// 修改报价函信息-存款
export function updateDeposit_offer(data) {
  return request({
    url: '/business/deposit_offer',
    method: 'put',
    data: data
  })
}

// 删除报价函信息-存款
export function delDeposit_offer(id) {
  return request({
    url: '/business/deposit_offer/' + id,
    method: 'delete'
  })
}

// 导出报价函信息-存款
export function exportDeposit_offer(query) {
  return request({
    url: '/business/deposit_offer/export',
    method: 'get',
    params: query
  })
}

//查询分配结果
export function listAllocationResult(params) {
  return request({
    url: '/business/deposit_offer/allocationResult',
    method: 'get',
    params: params
  })
}
