import request from '@/utils/request'

// 查询报价函信息-借款列表
export function listLoan_offer(query) {
  return request({
    url: '/business/loan_offer/list',
    method: 'get',
    params: query
  })
}

// 查询报价函信息-借款详细
export function getLoan_offer(id) {
  return request({
    url: '/business/loan_offer/' + id,
    method: 'get'
  })
}

// 新增报价函信息-借款
export function addLoan_offer(data) {
  return request({
    url: '/business/loan_offer',
    method: 'post',
    data: data
  })
}

// 修改报价函信息-借款
export function updateLoan_offer(data) {
  return request({
    url: '/business/loan_offer',
    method: 'put',
    data: data
  })
}

// 删除报价函信息-借款
export function delLoan_offer(id) {
  return request({
    url: '/business/loan_offer/' + id,
    method: 'delete'
  })
}

// 导出报价函信息-借款
export function exportLoan_offer(query) {
  return request({
    url: '/business/loan_offer/export',
    method: 'get',
    params: query
  })
}

// 导出报价函信息-存款
export function listAllocationResult(query) {
  return request({
    url: '/business/loan_offer/allocationResult',
    method: 'get',
    params: query
  })
}
