<template>
  <div :class="classObj" class="app-wrapper" style="min-width: 500px; ">
    <header>
      <div class="header-top">
        <div class="company-logo"><logo :collapse="true"></logo></div>
        <div class="system-name">
          <span>资金询价系统</span>
        </div>
        <div class="user-center"><user-center></user-center></div>
      </div>

      <div :class="{'fixed-header':fixedHeader}" class="header-tag">
        <navbar />
        <tags-view v-if="needTagsView" />
      </div>
    </header>
    <div v-if="device==='mobile'&&sidebar.opened" class="drawer-bg" @click="handleClickOutside" />
      <sidebar class="sidebar-container" />
      <div :class="{hasTagsView:needTagsView}" class="main-container">

        <app-main />

        <right-panel v-if="showSettings">
          <settings />
        </right-panel>
    </div>
  </div>
</template>

<script>
import RightPanel from '@/components/RightPanel'
import { AppMain, Navbar, Settings, Sidebar, TagsView } from './components'
import ResizeMixin from './mixin/ResizeHandler'
import { mapState } from 'vuex'
import Logo from './components/Sidebar/Logo'
import UserCenter from './components/Navbar'

export default {
  name: 'Layout',
  components: {
    AppMain,
    Navbar,
    RightPanel,
    Settings,
    Sidebar,
    TagsView,
    Logo,
    UserCenter
  },
  mixins: [ResizeMixin],
  computed: {
    ...mapState({
      sidebar: state => state.app.sidebar,
      device: state => state.app.device,
      showSettings: state => state.settings.showSettings,
      needTagsView: state => state.settings.tagsView,
      fixedHeader: state => state.settings.fixedHeader
    }),
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile'
      }
    }
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('app/closeSideBar', { withoutAnimation: false })
    }
  }
}
</script>

<style lang="scss" scoped>
  @import "~@/assets/styles/mixin.scss";
  @import "~@/assets/styles/variables.scss";

  .app-wrapper {
    @include clearfix;
    position: relative;
    height: 100%;
    width: 100%;

    &.mobile.openSidebar {
      position: fixed;
      top: 0;
    }
  }

  .system-name{
    color: #fff;
    font-size: 26px;
    text-align: center;
    position: absolute;
    padding: 19px 0px;
    white-space:nowrap;
    width: calc(100vw - 380px);
    .span{
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
    }
  }
  .header-top {
    height: 65px;
    /*background: #2c3e50;*/
    /*background: #21a7fc;*/
    background-image: url("../assets/image/top-bg.png");
    > div {
      display: inline-block;
    }
    .header-tag{
      height: 20px;
      position: relative;

    }
    .user-center {
      float: right;

      /deep/ {
        .hamburger-container,
        .el-breadcrumb {
          display: none;
        }

        .right-menu {
          display: block;
          /*background: #21a7fc;*/
        }
      }
    }
  }


  .drawer-bg {
    background: #000;
    opacity: 0.3;
    width: 100%;
    top: 0;
    height: 100%;
    position: absolute;
    z-index: 999;
  }

  .fixed-header {
    position: fixed;
    top: 0;
    right: 0;
    z-index: 9;
    width: calc(100% - #{$sideBarWidth});
    transition: width 0.28s;
  }

  .hideSidebar .fixed-header {
    width: calc(100% - 54px)
  }

  .mobile .fixed-header {
    width: 100%;
  }
</style>
