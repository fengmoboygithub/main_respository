<template>
  <el-card style='margin: 25px 30px 0 25px;width=100%;'>
    <el-form ref="form" :model="form" label-width="150px" size="mini">
      <el-row>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="询价函编号：">{{ form.inquiryNo }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="询价函名称：" >{{ form.inquiryName }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="融资规模(元)：">{{currencyFormat(form)}}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="融资期限：">{{ form.limitTime }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="融资品种：">{{ form.type }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="起息日期区间：">{{ form.beginTime }} - {{ form.endTime }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="报价起始时间：">{{ form.quoteStart }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="报价截止时间：">{{ form.quoteEnd }}</el-form-item>
        </el-col>
        <el-col :span="24" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="发送银行：" prop="bankIds">
            <span v-for="bank in banks" :key="bank.id">
              <span v-if="bank.isActive">
                {{bank.name}}&nbsp;&nbsp;
              </span>
            </span>
          </el-form-item>
        </el-col>
        <el-col :span="24" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="短信内容：">{{ form.messageContent }}</el-form-item>
        </el-col>
        <el-col :span="24" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="状态：">{{ statusFormat(form) }}</el-form-item>
        </el-col>
        <span v-if="ckd=='2'">
          <el-col :span="24" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
            <el-form-item label="备注" prop="remark">
              <el-input v-model="form.remark" type="textarea"  placeholder="请输入备注" />
            </el-form-item>
          </el-col>
        </span>
        <span v-if="form.status==4">
          <el-col :span="24" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
            <el-form-item label="备注：" prop="remark">
              {{ form.remark }}
            </el-form-item>
          </el-col>
        </span>
      </el-row>
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
        <span v-if="ckd==1">
          <el-button type="primary" @click="submitForm(2)">审核通过</el-button>
          <el-button type="primary" @click="submitForm(0)">审核不通过</el-button> &nbsp;
        </span>
        <span v-if="ckd==2">
          <el-button type="primary" @click="submitForm(4)">确认取消</el-button>
        </span>
        <el-button type="primary" @click="close()">关 闭</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>
<script>
import { getLoan, checkLoan, cancelLoan, listBanks } from "@/api/business/loan";

export default {
  name: "LoanView",
  components: {},
  data() {

    return {
      // 表详细信息
      form: {id: '', inquiryNo: '',  remark:'', status:''},
      ckd: '0',
      selectedBankIds: [],
      banks: {},
      // 状态数据字典
      statusOptions: [],
      ttypes: '',
      // 字典信息
      loanTypeOptions: []
    };
  },
  created(){
    this.getDetail();
  },
  watch: {
    "$route"(val,oldval){
      if(val.meta.title=='询价函详情'){
        this.getDetail();
      }
    }
  },
  beforeCreate() {

    const { checked } = this.$route.query;
    this.getDicts("busi_deposit_status").then(response => {
      this.statusOptions = response.data;
    });

    /** 查询字典下拉列表 */
    this.getDicts("busi_loan_type").then(response => {
      this.loanTypeOptions = response.data;
    });
  },
  methods: {
    // 存放规模财务货币化
    currencyFormat(form) {
        const value = form.amount;
        if(!value) return '';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        //=2表示数据有小数位
        if(value2Array.length == 2) {
          floatPart = value2Array[1].toString(); //拿到小数部分
          if(floatPart.length == 1){
            floatPart += '0';
          }
        }
        return intPartFormat + '.' +floatPart;
    },
    /** 关闭按钮 */
    close() {
      this.$store.dispatch("tagsView/delView", this.$route);
      this.$router.push({ path: "/business/loan" });
    },
    // 询价函状态字典翻译
    statusFormat(row, column) {
      return this.selectDictLabel(this.statusOptions, row.status);
    },
    getDetail() {
      const { id } = this.$route.query;
      const { checked } = this.$route.query;
      this.ckd = checked;

      if (id) {
        // 获取表详细信息
        getLoan(id).then(ress => {
          this.ttypes = ress.data.type;
          var rtTypes = [];
          if(this.ttypes){
            var types = this.ttypes.split(',');
            for(var i=0; i<types.length; i++){
              rtTypes.push(this.selectDictLabel(this.loanTypeOptions, types[i]));
            }
          }
          ress.data.type = rtTypes.join(',');
          this.form = ress.data;

          //获取银行列表
          listBanks().then(res => {
            this.banks = res.data;
            if(this.form.bankIds){
              var bs = this.form.bankIds.split(',');
              this.selectedBankIds = this.form.bankIds.split(',');
              this.banks.map(item => {
                bs.forEach(function(value,key,arr) {
                  if(value == item.id){
                    item.isActive = true;
                  }
                });
              });
            }
          });
        });
      }
    },
    /** 提交按钮 */
    submitForm(val) {
      var resultmsg = '';
      if(val == 4){
        resultmsg = '取消';
       if(this.form.remark==undefined || this.form.remark==null || this.form.remark==''){
        this.msgError("备注不能为空");
        return;
       }
      }else if(val == 2){
        resultmsg = '审核通过';
      }else{
        resultmsg = '审核不通过';
      }
      //this.form.status = val;
      const did = this.form.id;
      const dremark = this.form.remark;
      const dstatus = val;
      const inquiryNo = this.form.inquiryNo;
      this.$confirm('是否确认'+resultmsg+'询价函编号为"' + inquiryNo + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        if(val == 4){
          return cancelLoan(did, dremark, dstatus,inquiryNo);
        }else{
          return checkLoan(did, dstatus,inquiryNo);
        }
      }).then(() => {
        this.msgSuccess(resultmsg+"成功");
        this.close();
      }).catch(function() {
        this.msgError(resultmsg+"失败");
      });

    }
  }
};
</script>
