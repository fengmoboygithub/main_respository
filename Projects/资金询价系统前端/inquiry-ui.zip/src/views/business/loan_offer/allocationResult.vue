<template>
  <el-card>
    <p style="font-weight:900;font-size: 18px">报价单统计</p>
    <el-table :data="resultData" :span-method="objectSpanMethod"
              show-summary
              :summary-method="getTotal"

    >
      <el-table-column label="序号" >
        <template slot-scope="scope">
          {{scope.$index+1}}
        </template>
      </el-table-column>
      <el-table-column
        prop="interestRate"
        label="利率">
      </el-table-column>
      <el-table-column
        prop="type"
        label="融资品种">
      </el-table-column>
      <el-table-column
        prop="timeLimit"
        label="融资期限">
      </el-table-column>
      <el-table-column
        prop="distributionAmount"
        label="分配金额" :formatter="currencyFormat">
      </el-table-column>
      <el-table-column
        prop="scale"
        label="报价金额" :formatter="currencyFormat">
      </el-table-column>
    </el-table>
    <el-form label-width="100px">
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
        <el-button @click="close()">返回</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>
<script>
  import {listAllocationResult} from "@/api/business/loan_offer/loan_offer";
  export default {
    name: "loan_allocation_result_view",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // 字典表格数据
        dataList: [],
        // 默认字典类型
        defaultDictType: "",
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        //分配结果数据
        resultData: [],
        // 选中选项卡的 name
        activeName: "cloum",
        // 表格的高度
        tableHeight: document.documentElement.scrollHeight - 245 + "px",
        // 表列信息
        cloumns: []
      };
    },
    watch: {
    },
    created(){
      let {id} = this.$route.query;
      this.resultData = this.getAllocationResult(id);
    },
    methods: {
      close(){
        this.$store.dispatch("tagsView/delView", this.$route);
        this.$router.push({ path: "/business/loan_offer"});
      },
      // 存放规模财务货币化
      currencyFormat(form, column) {
        let value = null;
        if(column.property == 'scale'){
          value = form.scale;
        }else if(column.property == 'distributionAmount'){
          value = form.distributionAmount;
        }
        if(!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        //=2表示数据有小数位
        if(value2Array.length == 2) {
          floatPart = value2Array[1].toString(); //拿到小数部分
          if(floatPart.length == 1){
            floatPart += '0';
          }
        }
        return intPartFormat + '.' +floatPart;
      },
      getTotal(param){
        const { columns, data } = param;
        const sums = [];
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '合计';
            return;
          }else if (index == 1 ){
            sums[index] = '--';
            return;
          }else {
            const values = data.map(item => Number(item[column.property]));
            if (!values.every(value => isNaN(value))) {
              sums[index] = values.reduce((prev, curr) => {
                const value = Number(curr);
                if (!isNaN(value)) {
                  return prev + curr;
                } else {
                  return prev;
                }
              }, 0);
              sums[index] += ' 元';
            }
          }

        });
        return sums;
      },
      rowClass(){
        return 'border-color: #868686; color: #606266'
      },
      cellStyle(){
        return 'border-color: #868686'
      },
      /** 列表组合 */
      objectSpanMethod({row, column, rowIndex, columnIndex}) {
        const span = column['property'] + '-span'
        if (row[span]) {
          return row[span]
        }
      },
      getAllocationResult(id){
        let params = {};
        params.id = id;
        //查询后台没有分配结果
        listAllocationResult(params).then(response => {
          let data = response.data;
          this.resultData = data;
        });
      }
    }
  }
</script>
