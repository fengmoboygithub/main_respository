<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="85px">
        <el-row>
          <el-form-item label="询价函编号" prop="inquiryNo">
            <el-input
              v-model="queryParams.inquiryNo"
              placeholder="请输入询价函编号"
              clearable
              size="small"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>


          <el-form-item label="询价函名称" prop="inquiryName">
            <el-input
              v-model="queryParams.inquiryName"
              placeholder="请输入询价函名称"
              clearable
              size="small"
              style="width: 240px"
              @keyup.enter.native="handleQuery"
            />
          </el-form-item>


          <el-form-item label="询价函状态"  prop="status" >
            <el-select
              v-model="queryParams.status"
              placeholder="请选择询价函状态"
              clearable
              size="small"
              style="width: 240px"
            >
              <el-option
                v-for="dict in statusOptions"
                :key="dict.dictValue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              />
            </el-select>
          </el-form-item>

          <el-form-item label="报价开始时间" prop="quoteStart" label-width="96px">
            <el-date-picker clearable size="small"
                            v-model="queryParams.quoteStart"
                            type="date"
                            :editable="false"
                            value-format="yyyy-MM-dd"
                            placeholder="选择报价开始时间">
            </el-date-picker>
          </el-form-item>

          <el-form-item label="报价截止时间" prop="quoteEnd" label-width="96px" >
            <el-date-picker clearable size="small"
                            v-model="queryParams.quoteEnd"
                            type="date"
                            :editable="false"
                            value-format="yyyy-MM-dd"
                            placeholder="选择报价截止时间">
            </el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-row>
    </el-form>

    <el-table v-loading="loading" :data="loan_offerList"  @selection-change="handleSelectionChange">
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
          {{scope.$index+1}}
        </template>
      </el-table-column>
      <el-table-column label="id" align="center" v-if="show" hidden="hidden" prop="id" />
      <el-table-column label="询价函编号" align="center" prop="inquiryNo" />
      <el-table-column label="询价函名称" align="center" prop="inquiryName" />
      <el-table-column label="融资规模" align="center" prop="amount" :formatter="currencyFormat"/>
      <el-table-column label="融资期限" align="center" prop="limitTime" />
      <el-table-column label="起息日期区间" align="center" prop="inquiryBeginTime":formatter="beTimeFormat" width="180">
      </el-table-column>
      <el-table-column label="报价开始时间" align="center" prop="quoteStart" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.quoteStart, '{y}-{m}-{d} {h}:{i}:{s}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="报价截止时间" align="center" prop="quoteEnd" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.quoteEnd, '{y}-{m}-{d} {h}:{i}:{s}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="询价函状态" align="center" prop="inquiryStatus" :formatter="inquiryStatusFormat" />
      <el-table-column label="报价函状态" align="center" prop="status" :formatter="depositStatusFormat" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button v-if="scope.row.inquiryStatus == 2 && scope.row.status != 2"
                     size="mini"
                     type="text"
                     icon="el-icon-edit"
                     @click="handleUpdate(scope.row)"
                     v-hasPermi="['business:loan_offer:edit']"
          >报价</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="handleDetail(scope.row)"
            v-hasPermi="['business:loan_offer:query']"
          >查看</el-button>
          <el-button v-if="scope.row.inquiryStatus == 2 && scope.row.status == 2"
                     size="mini"
                     type="text"
                     icon="el-icon-delete"
                     @click="handleDelete(scope.row)"
                     v-hasPermi="['business:loan_offer:return']"
          >撤回</el-button>
          <el-button v-if="scope.row.showAllocationBut"
                     size="mini"
                     type="text"
                     icon="el-icon-goods"
                     @click="viewAllocationResult(scope.row)"
                     v-hasPermi="['business:loan_offer:allocation']"
          >分配结果</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

  </div>
</template>

<script>
import { listLoan_offer, getLoan_offer, delLoan_offer, addLoan_offer, updateLoan_offer, exportLoan_offer } from "@/api/business/loan_offer/loan_offer";
import {parseTime} from "../../../utils/inquiry";

export default {
  name: "loan_offer",
  data() {
    return {
      // 遮罩层
      loading: true,
      show: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 总条数
      total: 0,
      // 报价函信息-借款表格数据
      loan_offerList: [],
      // 询价函状态数据字典
      statusOptions: [],
      // 报价函状态数据字典
      depositOfferStatus: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        inquiryNo: undefined,
        inquiryName: undefined,
        status: undefined,
        quoteStart: undefined,
        quoteEnd: undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        inquiryId: [
          { required: true, message: "询价函id不能为空", trigger: "blur" }
        ],
        status: [
          { required: true, message: "询价函状态(0:草稿, 1:已提交)不能为空", trigger: "blur" }
        ],
        delFlag: [
          { required: true, message: "删除状态(0:已删除, 1:正常)不能为空", trigger: "blur" }
        ],
        bankId: [
          { required: true, message: "银行操作人的id不能为空", trigger: "blur" }
        ],
      }
    };
  },
  created() {
    this.getList();
    this.getDicts("busi_deposit_status").then(response => {
      let statusArr = response.data;
      for(let i = 0; i < statusArr.length; i++){
        if(statusArr[i].dictLabel != '草稿' && statusArr[i].dictLabel != '待复核'){
          this.statusOptions.push(statusArr[i]);
        }
      }
      // this.statusOptions = response.data;
    });
    this.getDicts("busi_deposit_offer_status").then(response => {
      this.depositOfferStatus = response.data;
    });
  },
  methods: {
    // 存放规模财务货币化
    currencyFormat(form) {
      const value = form.amount;
      if(!value) return '0';
      var intPart = Number(value).toFixed(0); //获取整数部分
      var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
      var floatPart = "00"; //预定义小数部分
      var value2Array = value.split(".");
      //=2表示数据有小数位
      if(value2Array.length == 2) {
        floatPart = value2Array[1].toString(); //拿到小数部分
        if(floatPart.length == 1){
          floatPart += '0';
        }
      }
      return intPartFormat + '.' +floatPart;
    },
    /** 查询报价函信息-借款列表 */
    getList() {
      this.loading = true;
      listLoan_offer(this.queryParams).then(response => {
        this.loan_offerList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 起息起始日期
    beTimeFormat(row, column) {
      return parseTime(row.inquiryBeginTime, '{y}-{m}-{d}') + ' - ' + parseTime(row.inquiryEndTime, '{y}-{m}-{d}');
    },
    // 字典状态字典翻译
    inquiryStatusFormat(row, column) {
      return this.selectDictLabel(this.statusOptions, row.inquiryStatus);
    },
    depositStatusFormat(row, column){
      return this.selectDictLabel(this.depositOfferStatus, row.status);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: undefined,
        inquiryId: undefined,
        status: "0",
        delFlag: undefined,
        remark: undefined,
        submitTime: undefined,
        updateTime: undefined,
        bankId: undefined,
        submitName: undefined,
        submitPhone: undefined
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },

    viewAllocationResult(row){
      const id = row.id || this.ids;
      this.$router.push({ path: "/loan_offer/allocationResult", query: { id: id,title: '分配结果报价函信息-存款'} });
    },
    /** 提交按钮 */
    /*submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            updateLoan_offer(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
              }
            });
          } else {
            addLoan_offer(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              }
            });
          }
        }
      });
    },*/
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      let inquiryNo = row.inquiryNo;
      this.$confirm('是否确认撤回报价函信息-询价函编号为"' + inquiryNo + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delLoan_offer(ids);
        }).then(() => {
          this.getList();
          this.msgSuccess("撤回成功");
        }).catch(function() {});
    },
    handleDetail(row){
      let id = row.id || this.ids;
      let param = {};
      param.id = id;
      param.state='0';
      param.isHiddenBut=false;
      param.title='查看报价函信息-借款';
      this.$router.push({ path: "/loan_offer/detail", query: param});
    },
    /** 报价按钮操作 */
    handleUpdate(row) {
      let id = row.id || this.ids;
      let param = {};
      param.id = id;
      param.state='1';
      param.isHiddenBut=true;
      param.title='修改报价函信息-借款';
      this.$router.push({ path: "/loan_offer/edit", query: param});
    }
  }
};
</script>
