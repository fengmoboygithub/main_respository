<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="100px">
      <el-form-item label="询价函编号" prop="inquiryNo">
        <el-input
          v-model="queryParams.inquiryNo"
          placeholder="请输入询价函编号"
          size="small"
          style="width: 200px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="询价函名称" prop="inquiryName">
        <el-input
          v-model="queryParams.inquiryName"
          placeholder="请输入询价函名称"
          size="small"
          style="width: 200px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="起存日期" prop="beginTime">
        <el-date-picker
              v-model="queryParams.beginTime"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="起存日期"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="报价开始时间" prop="quoteStart">
        <el-date-picker
              v-model="queryParams.quoteStart"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd HH:mm:ss"
              type="datetime"
              placeholder="报价开始时间"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="报价截止时间" prop="quoteEnd">
        <el-date-picker
              v-model="queryParams.quoteEnd"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd HH:mm:ss"
              type="datetime"
              placeholder="报价截止时间"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status"  placeholder="状态" clearable size="small" style="width: 200px" >
          <el-option
            v-for="dict in statusOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>
      <el-form-item style="float:right;">
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
    </el-row>

    <el-table v-loading="loading" :data="depositList" @selection-change="handleSelectionChange">
<!--      <el-table-column type="selection" width="45" align="center" />-->
      <!-- <el-table-column label="序号" type="index" width="50" align="center">
        <template slot-scope="scope">
          <span>{{(queryParams.pageNum - 1) * queryParams.pageSize + scope.$index + 1}}</span>
        </template>
      </el-table-column> -->
      <el-table-column label="询价函编号" align="center" prop="inquiryNo" min-width="130%"/>
      <el-table-column label="询价函名称" align="center" prop="inquiryName" />
      <el-table-column label="存放规模(元)" align="center" prop="amount" :formatter="currencyFormat"/>
      <el-table-column label="存放期限" align="center" prop="limitTime" :formatter="limitFormat" />
      <el-table-column label="起存日期" align="center" prop="beginTime" />
      <!-- <el-table-column label="到期日期" align="center" prop="dueTime" /> -->
      <el-table-column label="报价开始时间" align="center" prop="quoteStart" />
      <el-table-column label="报价截止时间" align="center" prop="quoteEnd" />
      <!-- <el-table-column label="创建时间" align="center" prop="createTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="创建人" align="center" prop="creator" width="180" />
      <el-table-column label="复核时间" align="center" prop="reviewTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.reviewTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="复核人" align="center" prop="reviewer" width="180" /> -->
      <el-table-column label="状态" align="center" prop="status" :formatter="statusFormat" />
      <el-table-column label="报价结果" align="center" prop="result" >
      <template slot-scope="scope">
        <p v-if="scope.row.status=='2' || scope.row.status=='4' ">
          <el-button
              size="mini"
              type="text"
              icon="el-icon-view"
              @click="ViewDepositDetails(scope.row)"
              v-hasPermi="['business:statistics:result']"
            >查看</el-button>
          </p>
        <p v-if="scope.row.status=='3'">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="ViewDepositStatistics(scope.row)"
            v-hasPermi="['business:statistics:result']"
          >查看统计</el-button>
        </p>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" width="230">
        <template slot-scope="scope" >
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="handleViewDeposit(scope.row)"
            v-hasPermi="['business:deposit:query']"
          >详情</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

  </div>
</template>

<script>
import {delDeposit} from "@/api/business/deposit";
import {removeDeafList} from "@/api/business/audit_statistics";
export default {
  name: "deposit",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 总条数
      total: 0,
      // 询价函表格数据
      depositList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 状态数据字典
      statusOptions: [],
      //存放期限单位字典
      limitOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        inquiryNo: undefined,
        inquiryName: undefined,
        beginTime: undefined,
        status: undefined
      },
      // 表单参数
      form: {},
    };
  },
  created() {
    this.getList();
    this.getDicts("busi_deposit_status").then(response => {
      this.statusOptions = response.data;
      this.$delete(response.data,'0');
      //console.log(response.data);
    });
    this.getDicts("busi_deposit_limit_unit").then(response => {
      this.limitOptions = response.data;
    });
  },
  methods: {
    /** 查询询价函列表 */
    getList() {
      this.loading = true;
      removeDeafList(this.queryParams).then(response => {
        this.depositList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 存放期限单位字典翻译
    limitFormat(row, column) {
      return row.limitTime + this.selectDictLabel(this.limitOptions, row.limitUnit);
    },
    // 存放规模财务货币化
    currencyFormat(row, column) {
        const value = row.amount;
        if(!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = ".000000"; //预定义小数部分
        var value2Array = value.split(".");
        //=2表示数据有小数位
        if(value2Array.length == 2) {
        floatPart = value2Array[1].toString(); //拿到小数部分
        if(floatPart.length == 1) { //补0,实际上用不着
          return intPartFormat + "." + floatPart + '00000';
        }else if(floatPart.length == 2) { //补0,实际上用不着
          return intPartFormat + "." + floatPart + '0000';
        }else if(floatPart.length == 3) { //补0,实际上用不着
          return intPartFormat + "." + floatPart + '000';
        }else if(floatPart.length == 4) { //补0,实际上用不着
          return intPartFormat + "." + floatPart + '00';
        }else if(floatPart.length == 5) { //补0,实际上用不着
          return intPartFormat + "." + floatPart + '0';
        }else {
          return intPartFormat + "." + floatPart;
        }
        } else {
        return intPartFormat + floatPart;
        }
    },
    // 询价函状态字典翻译
    statusFormat(row, column) {
      return this.selectDictLabel(this.statusOptions, row.status);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 新增修改按钮操作 */
    handleAddDeposit(row) {
      const id = row.id || this.ids[0];
      if(id){
        this.$router.push({ path: "/deposit/edit", query: { id: id}});
      }else{
        this.$router.push({ path: "/deposit/add", query: { id: id}});
      }

    },
    /** 详情操作 */
    handleViewDeposit(row) {
      const id = row.id ;
      this.$router.push({ path: "/deposit/query", query: { id: id}});
    },
    /** 报价结果 */
    ViewDepositDetails(row) {
      const id = row.id ;
      this.$router.push({ path: "/audit/result", query: { id: id}});
    },
    /** 报价结果统计 */
    ViewDepositStatistics(row) {
      const id = row.id ;
      this.$router.push({ path: "/audit/Statistics", query: { id: id}});
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            updatePost(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.getList();
              }
            });
          } else {
            addPost(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.getList();
              }
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const depositIds = row.id || this.ids;
      this.$confirm('是否确认删除询价函编号为"' + depositIds + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delDeposit(depositIds);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        }).catch(function() {
          this.msgError('删除失败');
        });
    }
  }
};
</script>
