<template>
  <el-card>
    <!--    <p style="font-weight:900;font-size: 18px">报价结果</p>-->
    <el-tabs v-model="activeName">
      <el-form ref="basicInfoForm" :model="info" label-width="100px">
        <el-row>
          <el-col :span="6">
            <el-form-item label="询价函编号" prop="inquiryNo">
              <el-input placeholder="" v-model="info.inquiryNo" value="1" :readonly="true"/>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="询价函名称" prop="inquiryName">
              <el-input placeholder="" v-model="info.inquiryName" :readonly="true"/>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="存放规模(元)" prop="amount">
              <el-input placeholder="" v-model="info.amount" :readonly="true"/>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="存放期限" prop="limitTime">
              <el-input placeholder="" v-model="info.limitTime" value="1" :readonly="true"/>
            </el-form-item>
          </el-col>

        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="起存日期" prop="beginTime">
              <el-input placeholder="" v-model="info.beginTime" :readonly="true"/>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="到期日期" prop="dueTime">
              <el-input placeholder="" v-model="info.dueTime" :readonly="true"/>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="发送银行" prop="bankIds">
              <el-input placeholder="" v-model="info.bankIds" :readonly="true"/>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="报价银行" prop="reviewer">
              <el-input placeholder="" v-model="info.reviewer" :readonly="true"/>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>


      <div class="app-container">
        <p style="font-weight:900;font-size: 18px">报价单统计</p>
        <el-table :data="elTable" :span-method="objectSpanMethod"
                  border
                  :header-cell-style="rowClass"
                  :cell-style="cellStyle"
        >

          <el-table-column
            prop="interestRate"
            label="利率"
          >
          </el-table-column>
          <el-table-column
            prop="bankId"
            label="报价人"
          >
            <!--            <template slot-scope="scope">-->
            <!--            <el-select-->
            <!--              v-model="scope.row.bankId"-->
            <!--              placeholder="选择银行"-->
            <!--              clearable-->
            <!--              size="small"-->
            <!--              style="width: 150px"-->
            <!--            >-->
            <!--              <el-option-->
            <!--                v-for="dict in banks"-->
            <!--                :key="dict.id"-->
            <!--                :label="dict.name"-->
            <!--                :value="dict.id"-->
            <!--              />-->
            <!--            </el-select>-->
            <!--            </template>-->
          </el-table-column>
          <el-table-column
            :formatter="currencyFormat"
            prop="scale"
            label="金额(元)">
          </el-table-column>
          <!--          <el-table-column-->
          <!--            prop="sumScale"-->
          <!--            label="累计金额">-->
          <!--          </el-table-column>-->
          <el-table-column
            prop="distributionAmount"
            label="分配金额(元)">
            <template slot-scope="scope">
              <el-input
                v-if="status==5"
                v-html="currencyFormatNumber(scope.row.distributionAmount)"
                v-model="scope.row.distributionAmount" readonly="readonly">
              </el-input>
              <div v-else>
                <el-input
                  @blur="check"
                  v-model="scope.row.distributionAmount">
                </el-input>
              </div>
            </template>
          </el-table-column>


        </el-table>

      </div>
    </el-tabs>
    <el-form label-width="100px">
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
        <el-button
          v-if="this.info.status!='5'"
          type="warning"
          icon="el-icon-download"
          size="mini"
          @click="assignSend"
          v-hasPermi="['business:statistics:assignSend']"
        >分配发送
        </el-button>
        <el-button @click="close()">关闭</el-button>
        <!--        <el-button @click="close()">分配</el-button>-->
      </el-form-item>
    </el-form>

  </el-card>
</template>

<div>

</div>
<script>
  import {listBanks} from "@/api/business/deposit";
  import {
    selectSysInquiryDepositById,
    exportDistribution,
    distribution,
    assignSendData
  } from "@/api/business/audit_statistics";

  /**
   *  table合并行通用 */
  export function mergeTableRow(data, merge) {
    if (!merge || merge.length === 0) {
      return data
    }
    merge.forEach((m) => {
      const mList = {}
      data = data.map((v, index) => {
        const rowVal = v[m]
        if (mList[rowVal] && mList[rowVal].newIndex === index) {
          mList[rowVal]['num']++
          mList[rowVal]['newIndex']++
          data[mList[rowVal]['index']][m + '-span'].rowspan++
          v[m + '-span'] = {
            rowspan: 0,
            colspan: 0
          }
        } else {
          mList[rowVal] = {num: 1, index: index, newIndex: index + 1}
          v[m + '-span'] = {
            rowspan: 1,
            colspan: 1
          }
        }
        return v
      })
    })
    return data
  }

  export default {
    name: "ViewDistribution",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // 字典表格数据
        dataList: [],
        // 默认字典类型
        defaultDictType: "",
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        // 状态数据字典
        statusOptions: [],
        // 类型数据字典
        typeOptions: [],
        //存放期限单位字典
        limitOptions: [],
        //银行列表
        banks: {},
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10
        },
        // 表单参数
        form: {},
        // 选中选项卡的 name
        activeName: "cloum",
        // 表格的高度
        tableHeight: document.documentElement.scrollHeight - 245 + "px",
        // 表列信息
        cloumns: [],
        // 字典信息
        dictOptions: [],
        // 表详细信息
        info: {},
        // 这里假设同一日期的数据是紧邻的 比如同一天日期的数据在前后顺序紧挨着
        elTable: [],
        // 存放表格日期单元格的rowspan和colspan信息
        spanArr: [],
        status: "",
        fg: true
      };
    },
    created() {
      const {id} = this.$route.query;
      const amount = this.$route.query.amount;
      const status = this.$route.query.status;
      this.status = status;
      //查询存放期限字典
      this.getDicts("busi_deposit_limit_unit").then(response => {
        this.limitOptions = response.data;
      });
      if (id) {
        // 获取询价信息
        selectSysInquiryDepositById(id).then(res => {
          this.info = this.limitFormat(res.data);
          this.info.amount=this.currencyFormatNumber(this.info.amount);
        });
        //获取报价统计列表
        distribution(id, amount, status).then(res => {
          this.elTable = res.data;
          // this.elTable.forEach(item1 => {
          //   this.banks.forEach(item2 => {
          //     if (item1.bankId == item2.id) {
          //       item1.bankId = item2.name;
          //       item1.phones = item2.phoneNumber;
          //       return true;
          //     }
          //   });
          // });

          this.elTable = mergeTableRow(this.elTable, ['interestRate']);
        });
      }
    },
    // computed:{为解决动态输入时的小数分隔
    //   changeRemarkLength(){
    //     //text就是所传参数
    //     return function (text) {
    //       text=this.currencyFormatNumber(text);
    //       console.log(text);
    //
    //       return text;
    //     }
    //   }
    // },
    methods: {
      rowClass() {
        return 'border-color: #868686; color: #606266'
      },
      cellStyle() {
        return 'border-color: #868686'
      },
      getBank() {
        listBanks().then(res => {
          this.banks = res.data;

        });
      },
      check(event) {
        // console.log(value.getInputElement());
        //console.log(value);
        if (!/^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/.test(event.srcElement.value)) {
          // value.srcElement.value = 123;
          event.srcElement.style = "border:#ff0000 1px solid"
          this.fg = false;
          open:{
            this.$alert('必须为正数数字类型且最多2位小数', '提示', {
              confirmButtonText: '确定',
              // callback: action => {
              //   this.function()
              // }
            });
          }
        } else {
          this.fg = true;
          event.srcElement.style = ""
        }
      },
      // 存放期限单位字典翻译
      limitFormat(data) {
        data.limitTime = data.limitTime + this.selectDictLabel(this.limitOptions, data.limitUnit);
        //console.log( data);
        return data;
      },
      // 取消按钮
      cancel() {
        this.open = false;
        this.reset();
      },
      // 表单重置
      reset() {
        this.form = {
          interestRate: undefined,
          scale: undefined
        };
        this.resetForm("form");
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.uuid)
        this.single = selection.length != 1
        this.multiple = !selection.length
      },
      /** 关闭按钮 */
      close() {
        const {id} = this.$route.query;
        const fpath = this.$route.query.fpath;
        this.$store.dispatch("tagsView/delView", this.$route);
        this.$router.push({path: "/audit/Statistics", query: {id: id, fpath: fpath}});
      },
      /** 详情操作 */
      distribution() {
        const {id} = this.$route.query;
        const {amount} = this.info.amount;

        this.$router.push({path: "/audit/distribution", query: {id: id, amount: amount}});
      },
      /** 列表组合 */
      objectSpanMethod({row, column, rowIndex, columnIndex}) {
        const span = column['property'] + '-span'
        //console.log(span);
        if (row[span]) {
          return row[span]
        }
      },
      assignSend() {
        let list = this.elTable;
        let id = this.info.id;
        let inquiryNo = this.info.inquiryNo;
        if (this.fg) {
          this.$confirm('是否根据当前数额分配？', "警告", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(function () {
            return assignSendData(list, id,inquiryNo);
          }).then(res => {
              this.$alert(res.msg, '分配结果', {
                confirmButtonText: '确定',
                callback: action => {
                  this.close();
                }
              });
            }
          );
        } else {
          this.$alert('校验失败，请检查当前分配金额（必须为正数数字类型且最多2位小数）', "警告", {
            confirmButtonText: "确定",
            type: "warning"
          })
        }
      }
      ,
      // 存放规模财务货币化
      currencyFormat(row, column) {
        //console.log( row[column.property]);
        const value = row[column.property];
        if (!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if (value2Array.length == 2) {
          floatPart = value2Array[1].toString();
        }
        return intPartFormat + '.' + floatPart;
      }
      ,
      // 存放规模财务货币化传参数修改
      currencyFormatNumber(number) {
        //console.log( row[column.property]);
        let value = number;
        if (!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if (value2Array.length == 2) {
          floatPart = value2Array[1].toString();
        }
        return intPartFormat + '.' + floatPart;
      }
      ,
      /** 导出按钮操作 */
      handleExport() {
        //const {id} = this.$route.query;
        let list = this.elTable;
        //console.log(list);
        this.$confirm('是否确认导出所有操作日志数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function () {
          return exportDistribution(list);
        }).then(response => {
          this.download(response.msg);
        }).catch(function () {
        });
      }


    }
  }
  ;
</script>
<style lang="scss" scoped>
  .el-table--border::after, .el-table--group::after, .el-table::before {
    background-color: black;
  }

  .el-table td, .el-table th.is-leaf, .el-table--border, .el-table--group {
    border-color: black;
  }
</style>
