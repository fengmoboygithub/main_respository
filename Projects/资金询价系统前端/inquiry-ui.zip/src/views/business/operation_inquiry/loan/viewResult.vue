<template>
  <div class="app-container">
    <p style="font-weight:900;font-size: 18px">询价函信息</p>
    <el-form ref="basicInfoForm" :model="info" label-width="100px">
      <el-row>
        <el-col :span="6">
          <el-form-item label="询价函编号" prop="inquiryNo">
            <el-input v-model="info.inquiryNo" value="1" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="询价函名称" prop="inquiryName">
            <el-input v-model="info.inquiryName" value="1" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="融资期限" prop="limitTime">
            <el-input v-model="info.limitTime" value="1" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="融资规模(元)" prop="amount">
            <el-input v-model="info.amount" :readonly="true"/>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="6">
          <el-form-item label="起息开始日期" prop="beginTime">
            <el-input v-model="info.beginTime" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="起息结束日期" prop="endTime">
            <el-input v-model="info.endTime" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="报价开始时间" prop="quoteStart">
            <el-input v-model="info.quoteStart" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="报价截止时间" prop="quoteEnd">
            <el-input v-model="info.quoteEnd" :readonly="true"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>


    <p style="font-weight:900;font-size: 18px">报价列表</p>
    <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="68px">
      <el-form-item label="状态" prop="state">
        <el-select
          v-model="queryParams.state"
          placeholder="请选择状态"
          clearable
          size="small"
          style="width: 240px"
        >
          <el-option
            v-for="dict in statusOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>

      <!--      <el-form-item label="报价银行" prop="bankId">-->
      <!--        <el-input-->
      <!--          v-model="queryParams.bankId"-->
      <!--          placeholder="请输入银行名称"-->
      <!--          clearable-->
      <!--          size="small"-->
      <!--          style="width: 240px"-->
      <!--        />-->
      <!--      </el-form-item>-->
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table v-loading="loading" :data="typeList" @selection-change="handleSelectionChange">
<!--      <el-table-column type="selection" width="55" align="center"/>-->
<!--      <el-table-column label="id" align="center" prop="id"/>-->
      <el-table-column label="序号" type="index" align="center" />
      <el-table-column label="报价银行" align="center" prop="bankId"/>
      <el-table-column label="状态" align="center" prop="state" :formatter="statusFormat"/>
<!--      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">-->
<!--        <template slot-scope="scope">-->
<!--          <el-button-->
<!--            v-if="scope.row.status=='2'"-->
<!--            size="mini"-->
<!--            type="text"-->
<!--            icon="el-icon-edit"-->
<!--            @click="handleDetail(scope.row)"-->
<!--            v-hasPermi="['business:deposit_offer:query']"-->
<!--          >详情-->
<!--          </el-button>-->
<!--          <span v-else>-->
<!--           未报价-->
<!--          </span>-->
<!--        </template>-->
<!--      </el-table-column>-->
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

  </div>
</template>

<script>
  import {loanOfferList, getLoan, listBanks} from "@/api/business/loan";

  export default {
    name: "DepositViewOver",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // 报价列表
        typeList: [],
        // 表详细信息
        info: {},
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        // 状态数据字典
        statusOptions: [],
        //存放期限单位字典
        limitOptions: [],
        // 日期范围
        dateRange: [],
        //银行列表
        banks: {},
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10,
          state: undefined,
          bankId: undefined
          // status: undefined
        },
        // 表单参数
        form: {},
        // 表单校验
        rules: {}
      };
    },
    created() {
      const {id} = this.$route.query;
      //this.getBank();
      this.getList();
      this.getDicts("busi_check_state").then(response => {
        this.statusOptions = response.data;
      });
      this.getDicts("busi_deposit_limit_unit").then(response => {
        this.limitOptions = response.data;
      });
      this.getFrom();
    },
    methods: {
      /**  查询询价关联的报价列表 */
      getList() {
        this.loading = true;
        this.queryParams.inquiryId = this.$route.query.id;
        loanOfferList(this.queryParams).then(response => {
            this.typeList = response.rows;
          // console.log(this.banks);
          //   this.typeList.forEach(item1 => {
          //     this.banks.map(item2 => {
          //       if (item1.bankId == item2.id) {
          //         item1.bankId = item2.name;
          //         return true;
          //       }
          //     });
          //   });
            //console.log(this.typeList);
            this.total = response.total;
            this.loading = false;
          }
        );
      },
      getBank() {
        listBanks().then(res => {
          this.banks = res.data;
        });
      },
      /**  查询询价关联的报价列表 */
      getFrom() {
        this.loading = true;
        getLoan(this.$route.query.id).then(response => {
            this.info = this.limitFormat(response.data);
          }
        );
      },
      // 字典状态字典翻译
      statusFormat(row, column) {
        return this.selectDictLabel(this.statusOptions, row.state);
      },
      // 存放期限单位字典翻译
      limitFormat(data) {
        data.limitTime = data.limitTime + this.selectDictLabel(this.limitOptions, data.limitUnit);
        //console.log( data);
        return data;
      },
      /** 搜索按钮操作 */
      handleQuery() {
        this.queryParams.pageNum = 1;
        this.getList();
      },
      /** 重置按钮操作 */
      resetQuery() {
        this.dateRange = [];
        this.resetForm("queryForm");
        this.handleQuery();
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.id)
        this.single = selection.length != 1
        this.multiple = !selection.length
      },
      /** 详情按钮操作 */
      // handleUpdate(row) {
      //   const id = row.id || this.ids;
      //   const xid = this.$route.query.id;
      //   this.$router.push({path: "/audit/view", query: {id: id, xid: xid, title: '报价函信息-存款'}});
      // },
      handleDetail(row){
        let id = row.id || this.ids;
        let param = {};
        param.id = id;
        param.state='2';
        param.isHiddenBut=false;
        //param.title='修改报价函信息-借款';
        this.$router.push({ path: "/loan_offer/detail", query: param});
      },
      /** 导出按钮操作 */
      handleExport() {
        const queryParams = this.queryParams;
        this.$confirm('是否确认导出所有类型数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function () {
          return exportType(queryParams);
        }).then(response => {
          this.download(response.msg);
        }).catch(function () {
        });
      },
      /** 清理缓存按钮操作 */
      // handleClearCache() {
      //   clearCache().then(response => {
      //     if (response.code === 200) {
      //       this.msgSuccess("清理成功");
      //     }
      //   });
      // }
    }
  };
</script>
