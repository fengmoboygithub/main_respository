<template>
  <el-card>
    <el-form ref="basicInfoForm" :model="info" label-width="100px">
      <el-row>
        <el-col :span="6">
          <el-form-item label="询价函编号" prop="inquiryNo">
            <el-input placeholder="" v-model="info.inquiryNo" value="1" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="融资规模(元)" prop="amount">
            <el-input placeholder="" v-model="info.amount" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="发送银行" prop="bankIds">
            <el-input placeholder="" v-model="info.bankIds" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="报价银行" prop="reviewer">
            <el-input placeholder="" v-model="info.reviewer" :readonly="true"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>


    <div class="app-container">

      <p style="font-weight:900;font-size: 18px">报价单统计（不区分期限）</p>
      <el-table :data="elTable" :span-method="objectSpanMethod"
                :summary-method="getSummaries5"
                show-summary
                border
                :header-cell-style="rowClass"
                :cell-style="cellStyle"
      >
        <el-table-column
          prop="interestRate"
          label="利率">
        </el-table-column>
        <el-table-column
          prop="bankId"
          label="报价人">
        </el-table-column>
        <el-table-column
          :formatter="currencyFormat"
          prop="scale"
          label="金额(元)">
        </el-table-column>
        <el-table-column
          prop="type"
          label="品种">
        </el-table-column>
        <el-table-column
          prop="timeLimit"
          label="期限">
        </el-table-column>
        <el-table-column
          :formatter="currencyFormat"
          prop="sumScale"
          label="累计金额(元)">
        </el-table-column>
      </el-table>

    </div>


    <div class="app2-container"
         v-for="(item,index) in deTable"
    >
      <p style="font-weight:900;font-size: 18px">报价统计{{item[0].timeLimit}}</p>
      <el-table
        :data="item"
        :span-method="objectSpanMethod"
        :summary-method="getSummaries4"
        show-summary
        border
        :header-cell-style="rowClass"
        :cell-style="cellStyle"
      >
        <el-table-column
          prop="interestRate"
          label="利率">
        </el-table-column>
        <el-table-column
          prop="bankId"
          label="报价人">
        </el-table-column>
        <el-table-column
          :formatter="currencyFormat"
          prop="scale"
          label="金额">
        </el-table-column>
        <el-table-column
          prop="type"
          label="品种">
        </el-table-column>
        <!--        <el-table-column-->
        <!--          prop="timeLimit"-->
        <!--          label="期限">-->
        <!--        </el-table-column>-->
        <el-table-column
          :formatter="currencyFormat"
          prop="sumScale"
          label="累计金额">
        </el-table-column>
      </el-table>
    </div>

    <el-form label-width="100px">
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
        <el-button
          type="warning"
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['business:statistics:export']"
        >导出
        </el-button>
        <el-button
          type="success"
          icon="el-icon-edit"
          size="mini"
          v-if="this.info.status!='5'"
          @click="distribution()">分配
        </el-button>
        <el-button
          type="success"
          icon="el-icon-edit"
          size="mini"
          v-if="this.info.status=='5'"
          @click="distribution2()">分配查询
        </el-button>
        <el-button @click="close()">返回</el-button>
      </el-form-item>
    </el-form>

    <el-dialog :title="title" :visible.sync="open" width="400px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="分配选择" prop="distributionId">
          <el-select v-model="form.distributionId" placeholder="请选择" clearable size="small">
            <el-option
              v-for="dict in deptOptions"
              :key="dict.timeLimit"
              :label="dict.timeLimit"
              :value="dict.timeLimit"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

  </el-card>
</template>


<script>
  import {listBanks} from "@/api/business/deposit";
  import {
    auditStatisticsLoanList,
    auditStatisticsLoanTermList,
    selectSysInquiryLoanById,
    exportInquiryLoan,
    listDistribution
  } from "@/api/business/audit_statistics";
  import {delTable} from "../../../../api/tool/gen";

  /**
   *  table合并行通用 */
  export function mergeTableRow(data, merge) {
    if (!merge || merge.length === 0) {
      return data
    }
    merge.forEach((m) => {
      const mList = {}
      data = data.map((v, index) => {
        const rowVal = v[m]
        if (mList[rowVal] && mList[rowVal].newIndex === index) {
          mList[rowVal]['num']++
          mList[rowVal]['newIndex']++
          data[mList[rowVal]['index']][m + '-span'].rowspan++
          v[m + '-span'] = {
            rowspan: 0,
            colspan: 0
          }
        } else {
          mList[rowVal] = {num: 1, index: index, newIndex: index + 1}
          v[m + '-span'] = {
            rowspan: 1,
            colspan: 1
          }
        }
        return v
      })
    })
    return data
  }

  export default {
    name: "ViewDepositStatistics",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // 字典表格数据
        dataList: [],
        // 分配选项
        deptOptions: [],
        // 默认字典类型
        defaultDictType: "",
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        //存放期限单位字典
        limitOptions: [],
        //银行列表
        banks: {},
        // // 状态数据字典
        // statusOptions: [],
        // // 类型数据字典
        // typeOptions: [],
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10
        },
        // 表单参数
        form: {
          distributionId: "不区分",
        },
        rules: {
          distributionId: [
            {required: true, message: "期限不能为空", trigger: "blur"}
          ]
        },
        // 选中选项卡的 name
        activeName: "cloum",
        // 表格的高度
        tableHeight: document.documentElement.scrollHeight - 245 + "px",
        // 字典信息
        dictOptions: [],
        // 表详细信息
        info: {},
        // 总统计表
        elTable: [],
        // 分期限计表
        deTable: [],
      };
    },
    //在使用Vue框架的时候，有时候需要在Vue在页面数据渲染完成之后调用方法，不然获取不到准确的数据，我们需要结合watch和this.$nextTick()来实现。
    //nextTick：在下次 DOM 更新循环结束之后执行延迟回调。
    //watch：用于观察Vue实例上的数据变动。对应一个对象,键是观察表达式,值是对应回调。
    watch: {
      deTable:{
        handler(val, oldVal){
          this.$nextTick(function () {
            let ball = document.getElementsByClassName('el-table__footer-wrapper');
            for(var i=0; i<ball.length; i++){
              ball[i].style.borderTop="1px solid ";
            }
          });
        },
        deep: true//true 深度监听
      },
      // "$route"(val,oldval){
      //   if(val.meta.title=='报价结果统计'){
      //     this.created();
      //   }
      // }
    },

    activated(){
      const {id} = this.$route.query;
      // 获取询价信息
      selectSysInquiryLoanById(id).then(res => {
        this.info = this.limitFormat(res.data);
        this.info.amount=this.currencyFormatNumber(this.info.amount);

      });
      //this.getBank();
      //console.log( this.banks);
      //查询存放期限字典
      this.getDicts("busi_deposit_limit_unit").then(response => {
        this.limitOptions = response.data;
      });
      if (id) {

        //获取报价统计列表
        auditStatisticsLoanList(id).then(res => {
          this.elTable = res.data;
          // this.elTable.forEach(item1 => {
          //   this.banks.forEach(item2 => {
          //     if (item1.bankId == item2.id) {
          //       item1.bankId = item2.name;
          //       return true;
          //     }
          //   });
          // });
          this.elTable = mergeTableRow(this.elTable, ['interestRate', 'sumScale']);
        });
        //获取报价期限统计列表
        auditStatisticsLoanTermList(id).then(res => {
          this.deTable = res.data;
          this.deTable.forEach(item1 => {
            item1 = mergeTableRow(item1, ['interestRate', 'sumScale']);
            // item1.forEach(item2 => {
            //   this.banks.forEach(item3 => {
            //     if (item2.bankId == item3.id) {
            //       item2.bankId = item3.name;
            //       return true;
            //     }
            //   });
            // });
          });
        });
      }
    },
    created() {

    },
    methods: {
      rowClass() {
        return 'border-color: #868686; color: #606266'
      },
      cellStyle() {
        return 'border-color: #868686'
      },
      // 存放规模财务货币化
      currencyFormat(row, column) {
        //console.log( row[column.property]);
        const value = row[column.property];
        if (!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if (value2Array.length == 2) {
          floatPart = value2Array[1].toString();
        }
        return intPartFormat + '.' + floatPart;
      },
      // 存放规模财务货币化传参数修改
      currencyFormatNumber(number) {
        //console.log( row[column.property]);
        let value = number;
        if (!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if (value2Array.length == 2) {
          floatPart = value2Array[1].toString();
        }
        return intPartFormat + '.' + floatPart;
      },
      //合计功能
      getSummaries5(param) {
        const { columns, data } = param;
        const sums = [];
        let hj = "";
        if(data.length !=0){
          hj = data[data.length-1].sumScale;
          hj = this.currencyFormatNumber(hj);
        }
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '合计';
            return;
          }else if (index === 5){
            sums[index] = hj;
          }else{
            sums[index] = "";
          }
        });

        return sums;
      },
      getSummaries4(param) {
        const { columns, data } = param;
        const sums = [];
        let hj = "";
        if(data.length !=0){
          hj = data[data.length-1].sumScale;
          hj = this.currencyFormatNumber(hj);
         // console.log(data[data.length-1].sumScale);
        }
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '合计';
            return;
          }else if (index === 4){
            sums[index] = hj;
          }else{
            sums[index] = "";
          }
        });

        return sums;
      },
      // 存放期限单位字典翻译
      limitFormat(data) {
        data.limitTime = data.limitTime + this.selectDictLabel(this.limitOptions, data.limitUnit);
        // console.log( data);
        return data;
      },
      getBank() {
        listBanks().then(res => {
          this.banks = res.data;
        });
      },
      /** 关闭按钮 */
      close() {
        const fpath = this.$route.query.fpath;
        this.$store.dispatch("tagsView/delView", this.$route);
        this.$router.push({path: fpath});
      },
      // 取消按钮
      cancel() {
        this.open = false;
        // this.reset();
      },
      /** 分配按钮*/
      distribution() {
        const {id} = this.$route.query;
        this.open = true;
        this.title = "分配选择";
        listDistribution(id).then(response => {
          this.deptOptions = response.data;
        });
      },
      distribution2() {
        let {id} = this.$route.query;
        let amount = this.info.amount;
        let status = this.info.status;
        let distributionId = this.info.assign;
        const fpath = this.$route.query.fpath;
        //console.log( this.info);
        this.$router.push({
          path: "/audit_loan/distribution",
          query: {id: id, amount: amount, distributionId: distributionId,status:status,fpath:fpath}
        });
      },
      submitForm: function () {
        this.$refs["form"].validate(valid => {
          if (valid) {
            const {id} = this.$route.query;
            const amount = this.info.amount;
            const status = this.info.status;
            let distributionId = this.form.distributionId;
            const fpath = this.$route.query.fpath;
            this.$router.push({
              path: "/audit_loan/distribution",
              query: {id: id, amount: amount, distributionId: distributionId,status:status,fpath:fpath}
            });
            this.open = false;
          }
        });
      },
      /** 列表组合 */
      objectSpanMethod({row, column, rowIndex, columnIndex}) {
        const span = column['property'] + '-span'
        if (row[span]) {
          return row[span]
        }
      },
      /** 导出按钮操作 */
      handleExport() {
        const {id} = this.$route.query;
        this.$confirm('是否确认导出统计结果数据?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function () {
          return exportInquiryLoan(id);
        }).then(response => {
          this.download(response.msg);
        }).catch(function () {
        });
      }


    }
  };
</script>
<style lang="scss" scoped>
  .el-table--border::after, .el-table--group::after, .el-table::before{
    background-color: black;
  }
  .el-table td, .el-table th.is-leaf,.el-table--border, .el-table--group{
    border-color: black;
  }
</style>
