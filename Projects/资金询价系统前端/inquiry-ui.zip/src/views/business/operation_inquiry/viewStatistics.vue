<template>
  <el-card>
    <!--    <p style="font-weight:900;font-size: 18px">报价结果</p>-->
    <el-form ref="basicInfoForm" :model="info" label-width="100px">
      <el-row>
        <el-col :span="6">
          <el-form-item label="询价函编号" prop="inquiryNo">
            <el-input placeholder="" v-model="info.inquiryNo" value="1" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="询价函名称" prop="inquiryName">
            <el-input placeholder="" v-model="info.inquiryName" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="存放规模(元)" prop="amount">
            <el-input placeholder="" v-model="info.amount" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="存放期限" prop="limitTime">
            <el-input placeholder="" v-model="info.limitTime" value="1" :readonly="true"/>
          </el-form-item>
        </el-col>

      </el-row>
      <el-row>
        <el-col :span="6">
          <el-form-item label="起存日期" prop="beginTime">
            <el-input placeholder="" v-model="info.beginTime" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="到期日期" prop="dueTime">
            <el-input placeholder="" v-model="info.dueTime" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="发送银行" prop="bankIds">
            <el-input placeholder="" v-model="info.bankIds" :readonly="true"/>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="报价银行" prop="reviewer">
            <el-input placeholder="" v-model="info.reviewer" :readonly="true"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>


    <div class="app-container">
      <p style="font-weight:900;font-size: 18px">报价单统计</p>
      <el-table :data="elTable"
                :span-method="objectSpanMethod"
                :summary-method="getSummaries"
                show-summary
                border
                :header-cell-style="rowClass"
                :cell-style="cellStyle"
      >
        <el-table-column
          prop="interestRate"
          label="利率"
        >
        </el-table-column>
        <el-table-column
          prop="bankId"
          label="报价人"
        >
        </el-table-column>
        <el-table-column
          :formatter="currencyFormat"
          prop="scale"
          label="金额(元)">
        </el-table-column>
        <el-table-column
          :formatter="currencyFormat"
          prop="sumScale"
          label="累计金额(元)">
        </el-table-column>
      </el-table>

    </div>
    <el-form label-width="100px">
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
        <el-button
          type="warning"
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['business:statistics:export']"
        >导出
        </el-button>
        <el-button
          type="success"
          icon="el-icon-edit"
          size="mini"
          @click="distribution()">
          <a v-if="this.info.status!='5'">分配</a>
          <a v-else>分配查询</a>
        </el-button>
        <el-button @click="close()">返回</el-button>
      </el-form-item>
    </el-form>

  </el-card>
</template>

<div>

</div>
<script>
  import {listBanks} from "@/api/business/deposit";
  import {
    auditStatisticsList,
    selectSysInquiryDepositById,
    exportInquiryDeposit
  } from "@/api/business/audit_statistics";

  /**
   *  table合并行通用 */
  export function mergeTableRow(data, merge) {
    if (!merge || merge.length === 0) {
      return data
    }
    merge.forEach((m) => {
      const mList = {}
      data = data.map((v, index) => {
        const rowVal = v[m]//merge所需数据
        if (mList[rowVal] && mList[rowVal].newIndex === index) {
          mList[rowVal]['num']++
          mList[rowVal]['newIndex']++
          data[mList[rowVal]['index']][m + '-span'].rowspan++//首个合并单元格中的rowspan++
          v[m + '-span'] = {//设置0，0使该行要合并的数据不显示
            rowspan: 0,
            colspan: 0
          }
        } else {//index当前V对象的下表data[index],newIndex下一个对象的下标，num当前合并数量（没用上）
          mList[rowVal] = {num: 1, index: index, newIndex: index + 1}
          v[m + '-span'] = {//新增一个data.merge-span的属性里面放置objectSpanMethod合并所需对象
            rowspan: 1,
            colspan: 1
          }
        }
        return v
      })
    })
    return data
  }

  export default {
    name: "ViewDepositStatistics",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 总条数
        total: 0,
        // 字典表格数据
        dataList: [],
        // 默认字典类型
        defaultDictType: "",
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        //存放期限单位字典
        limitOptions: [],
        //银行列表
        banks: {},
        // // 状态数据字典
        // statusOptions: [],
        // // 类型数据字典
        // typeOptions: [],
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10
        },
        // 表单参数
        form: {},
        // // 选中选项卡的 name
        // activeName: "cloum",
        // 表格的高度
        tableHeight: document.documentElement.scrollHeight - 245 + "px",
        // 表列信息
        cloumns: [],
        // 字典信息
        dictOptions: [],
        // 表详细信息
        info: {},
        // 这里假设同一日期的数据是紧邻的 比如同一天日期的数据在前后顺序紧挨着
        elTable: [],
        // 存放表格日期单元格的rowspan和colspan信息
        spanArr: []
      };
    },
    watch: {
      // "$route"(val,oldval){
      //   if(val.meta.title=='报价结果统计'){
      //     this.created();
      //   }
      // }
    },
    mounted() {
      let ball = document.getElementsByClassName('el-table__footer-wrapper');
      ball[0].style.borderTop = "1px solid ";
    },
    activated() {
      const {id} = this.$route.query;
      // 获取询价信息
      selectSysInquiryDepositById(id).then(res => {
        this.info = this.limitFormat(res.data);
        this.info.amount=this.currencyFormatNumber(this.info.amount);
      })
      //this.getBank();
      //查询存放期限字典
      this.getDicts("busi_deposit_limit_unit").then(response => {
        this.limitOptions = response.data;
      });
      if (id) {

        //获取报价统计列表
        auditStatisticsList(id).then(res => {
          this.elTable = res.data;
          // this.elTable.forEach(item1 => {
          //   this.banks.forEach(item2 => {
          //     if (item1.bankId == item2.id) {
          //       item1.bankId = item2.name;
          //       return true;
          //     }
          //   });
          // });
          this.elTable = mergeTableRow(this.elTable, ['interestRate', 'sumScale']);
        });
      }
    },
    created() {

    },
    methods: {

      rowClass() {
        return 'border-color: #868686; color: #606266'
      },
      cellStyle() {
        return 'border-color: #868686'
      },
      //合计功能
      getSummaries(param) {
        const {columns, data} = param;
        const sums = [];
        let hj = "";
        //const bh=data.get(1);
        if (data.length != 0) {
          hj = data[data.length - 1].sumScale;
          hj = this.currencyFormatNumber(hj);
        }
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '合计';
            return;
          } else if (index === 3) {
            sums[index] = hj;
          } else {
            sums[index] = "";
          }
        });

        return sums;
      },
      // 存放期限单位字典翻译
      limitFormat(data) {
        data.limitTime = data.limitTime + this.selectDictLabel(this.limitOptions, data.limitUnit);
        // console.log( data);
        return data;
      },
      getBank() {
        listBanks().then(res => {
          this.banks = res.data;
        });
      },
      // 取消按钮
      cancel() {
        this.open = false;
        this.reset();
      },
      // 表单重置
      reset() {
        this.form = {
          interestRate: undefined,
          scale: undefined
        };
        this.resetForm("form");
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.uuid)
        this.single = selection.length != 1
        this.multiple = !selection.length
      },
      /** 关闭按钮 */
      close() {
        const fpath = this.$route.query.fpath;
        this.$store.dispatch("tagsView/delView", this.$route);
        this.$router.push({path: fpath});
      },
      /** 分配按钮*/
      distribution() {
        const {id} = this.$route.query;
        const amount = this.info.amount;
        const status = this.info.status;
        const fpath = this.$route.query.fpath;
        this.$router.push({path: "/audit/distribution", query: {id: id, amount: amount, status: status, fpath: fpath}});
      },
      /** 列表组合 */
      objectSpanMethod({row, column, rowIndex, columnIndex}) {
        //查看el-ui官方文档合并单元格部分
        const span = column['property'] + '-span'
        if (row[span]) {
          return row[span]
        }
      },
      // 存放规模财务货币化
      currencyFormat(row, column) {
        //console.log( row[column.property]);
        const value = row[column.property];
        if (!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if (value2Array.length == 2) {
          floatPart = value2Array[1].toString();
        }
        return intPartFormat + '.' + floatPart;
      },
      // 存放规模财务货币化传参数修改
      currencyFormatNumber(number) {
        //console.log( row[column.property]);
        let value = number;
        if (!value) return '0';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if (value2Array.length == 2) {
          floatPart = value2Array[1].toString();
        }
        return intPartFormat + '.' + floatPart;
      },
      /** 导出按钮操作 */
      handleExport() {
        const {id} = this.$route.query;
        this.$confirm('是否确认导出统计结果数据?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function () {
          return exportInquiryDeposit(id);
        }).then(response => {
          this.download(response.msg);
        }).catch(function () {
        });
      }


    }
  };
</script>

<style lang="scss" scoped>
  .el-table--border::after, .el-table--group::after, .el-table::before {
    background-color: black;
  }

  .el-table td, .el-table th.is-leaf, .el-table--border, .el-table--group {
    border-color: black;
  }

</style>

