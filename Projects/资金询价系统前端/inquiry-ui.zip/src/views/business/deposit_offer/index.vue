<template>
  <div class="app-container">
      <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="85px">
        <el-row>

            <el-form-item label="询价函编号" prop="inquiryNo">
              <el-input
                v-model="queryParams.inquiryNo"
                placeholder="请输入询价函编号"
                clearable
                size="small"
                @keyup.enter.native="handleQuery"
              />
            </el-form-item>


            <el-form-item label="询价函名称" prop="inquiryName">
              <el-input
                v-model="queryParams.inquiryName"
                placeholder="请输入询价函名称"
                clearable
                size="small"
                style="width: 240px"
                @keyup.enter.native="handleQuery"
              />
            </el-form-item>


            <el-form-item label="询价函状态"  prop="status" >
              <el-select
                v-model="queryParams.status"
                placeholder="请选择询价函状态"
                clearable
                size="small"
                style="width: 240px"
              >
                <el-option
                  v-for="dict in statusOptions"
                  :key="dict.dictValue"
                  :label="dict.dictLabel"
                  :value="dict.dictValue"
                />
              </el-select>
            </el-form-item>

            <el-form-item label="起存日期" prop="inquiryBeginTime">
              <el-date-picker clearable size="small"
                              v-model="queryParams.inquiryBeginTime"
                              type="date"
                              value-format="yyyy-MM-dd"
                              placeholder="选择起存日期">
              </el-date-picker>
            </el-form-item>


            <el-form-item label="报价开始时间" prop="quoteStart" label-width="96px">
              <el-date-picker clearable size="small"
                              v-model="queryParams.quoteStart"
                              type="date"
                              value-format="yyyy-MM-dd"
                              placeholder="选择报价开始时间">
              </el-date-picker>
            </el-form-item>

            <el-form-item label="报价截止时间" prop="quoteEnd" label-width="96px" >
              <el-date-picker clearable size="small"
                              v-model="queryParams.quoteEnd"
                              type="date"
                              value-format="yyyy-MM-dd"
                              placeholder="选择报价截止时间">
              </el-date-picker>
            </el-form-item>
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-row>

    </el-form>

    <el-table v-loading="loading" :data="deposit_offerList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="40" align="center" />
      <el-table-column label="序号" width="50px">
        <template slot-scope="scope">
          {{scope.$index+1}}
        </template>
      </el-table-column>
      <el-table-column label="id" align="center" v-if="show" hidden="hidden" prop="id" />
      <el-table-column label="询价函编号" align="center" prop="inquiryNo" />
      <el-table-column label="询价函名称" align="center" prop="inquiryName" />
      <el-table-column label="存放规模" align="center" prop="amount" :formatter="currencyFormat"/>
      <el-table-column label="存放期限" align="center" prop="limitTime" />
      <el-table-column label="起存日期" align="center" prop="inquiryBeginTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.inquiryBeginTime, '{y}-{m}-{d} {h}:{i}:{s}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="报价开始时间" align="center" prop="quoteStart" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.quoteStart, '{y}-{m}-{d} {h}:{i}:{s}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="报价截至时间" align="center" prop="quoteEnd" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.quoteEnd, '{y}-{m}-{d} {h}:{i}:{s}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="询价函状态" align="center" prop="inquiryStatus" :formatter="inquiryStatusFormat" />
      <el-table-column label="报价函状态" align="center" prop="status" :formatter="depositStatusFormat" />
      <el-table-column label="操作" width="180" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button v-if="scope.row.inquiryStatus == 2 && scope.row.status != 2"
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['business:deposit_offer:edit']"
          >报价</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="handleDetail(scope.row)"
            v-hasPermi="['business:deposit_offer:query']"
          >查看</el-button>
          <el-button v-if="scope.row.inquiryStatus == 2 && scope.row.status == 2"
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['business:deposit_offer:return']"
          >撤回</el-button>
          <!--v-if="scope.row.inquiryStatus == 5"-->
          <el-button v-if="scope.row.showAllocationBut"
                     size="mini"
                     type="text"
                     icon="el-icon-goods"
                     @click="viewAllocationResult(scope.row)"
                     v-hasPermi="['business:deposit_offer:allocation']"
          >分配结果</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改报价函信息-存款对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="询价函id" prop="inquiryId">
          <el-input v-model="form.inquiryId" placeholder="请输入询价函id" />
        </el-form-item>
        <el-form-item label="询价函状态(0:草稿, 1:已提交)">
          <el-radio-group v-model="form.status">
            <el-radio label="1">请选择字典生成</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="删除状态(0:已删除, 1:正常)" prop="delFlag">
          <el-input v-model="form.delFlag" placeholder="请输入删除状态(0:已删除, 1:正常)" />
        </el-form-item>
        <el-form-item label="提交时间" prop="submitTime">
          <el-date-picker clearable size="small" style="width: 200px"
            v-model="form.submitTime"
            type="date"
            value-format="yyyy-MM-dd"
            placeholder="选择提交时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="银行操作人的id" prop="bankId">
          <el-input v-model="form.bankId" placeholder="请输入银行操作人的id" />
        </el-form-item>
        <el-form-item label="提交人名称" prop="submitName">
          <el-input v-model="form.submitName" placeholder="请输入提交人名称" />
        </el-form-item>
        <el-form-item label="提交人手机号" prop="submitPhone">
          <el-input v-model="form.submitPhone" placeholder="请输入提交人手机号" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listDeposit_offer, getDeposit_offer, delDeposit_offer, addDeposit_offer, updateDeposit_offer, exportDeposit_offer,listAllocationResult } from "@/api/business/deposit_offer/deposit_offer";

export default {
  name: 'deposit_offer',
  data() {
    return {
      // 遮罩层
      loading: true,
      //隐藏列
      show: false,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 总条数
      total: 0,
      // 报价函信息-存款表格数据
      deposit_offerList: [],
      // 询价函状态数据字典
      statusOptions: [],
      // 报价函状态数据字典
      depositOfferStatus: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        inquiryNo: undefined,
        inquiryName: undefined,
        status: undefined,
        inquiryBeginTime: undefined,
        quoteStart: undefined,
        quoteEnd: undefined
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        inquiryId: [
          { required: true, message: "询价函id不能为空", trigger: "blur" }
        ],
        status: [
          { required: true, message: "询价函状态(0:草稿, 1:已提交)不能为空", trigger: "blur" }
        ],
        delFlag: [
          { required: true, message: "删除状态(0:已删除, 1:正常)不能为空", trigger: "blur" }
        ],
        bankId: [
          { required: true, message: "银行操作人的id不能为空", trigger: "blur" }
        ],
      }
    };
  },
  created() {
    this.getList();
    this.getDicts("busi_deposit_status").then(response => {
        let statusArr = response.data;
        for(let i = 0; i < statusArr.length; i++){
          if(statusArr[i].dictLabel != '草稿' && statusArr[i].dictLabel != '待复核'){
            this.statusOptions.push(statusArr[i]);
          }
        }
        // this.statusOptions = response.data;
    });
    this.getDicts("busi_deposit_offer_status").then(response => {
      this.depositOfferStatus = response.data;
    });
  },
  methods: {
    // 存放规模财务货币化
    currencyFormat(form) {
      const value = form.amount;
      if(!value) return '0';
      var intPart = Number(value).toFixed(0); //获取整数部分
      var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
      var floatPart = "00"; //预定义小数部分
      var value2Array = value.split(".");
      //=2表示数据有小数位
      if(value2Array.length == 2) {
        floatPart = value2Array[1].toString(); //拿到小数部分
        if(floatPart.length == 1){
          floatPart += '0';
        }
      }
      return intPartFormat + '.' +floatPart;
    },
    /** 查询报价函信息-存款列表 */
    getList() {
      this.loading = true;
      listDeposit_offer(this.queryParams).then(response => {
        console.log(response.rows);
        this.deposit_offerList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 字典状态字典翻译
    inquiryStatusFormat(row, column) {
        return this.selectDictLabel(this.statusOptions, row.inquiryStatus);
    },
    depositStatusFormat(row, column){
      return this.selectDictLabel(this.depositOfferStatus, row.status);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
          inquiryNo: undefined,
          inquiryName: undefined,
          status: undefined,
          inquiryBeginTime: undefined,
          quoteStart: undefined,
          quoteEnd: undefined
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },

    /** 修改按钮操作 */
    handleUpdate(row) {
        const id = row.id || this.ids;
        this.$router.push({ path: "/deposit_offer/edit", query: {state: '1' , id: id ,title: '修改报价函信息-存款'} });
    },
    /** 查看按钮操作 */
    handleDetail(row) {
        const id = row.id || this.ids;
        this.$router.push({ path: "/deposit_offer/detail", query: { state: '0' , id: id ,title: '查看报价函信息-存款'} });
    },
    viewAllocationResult(row){
      const id = row.id || this.ids;
      this.$router.push({ path: "/deposit_offer/allocationResult", query: { state: '0' , id: id , isHiddenBut: false,title: '分配结果报价函信息-存款'} });
    },
    /*isShowAllocation: function (row) {
      let inquiryStatus = row.inquiryStatus;
      if (inquiryStatus != '5') {
        return false;
      }
      let params = {};
      params.id = row.id;
      //查询后台没有分配结果
      listAllocationResult(params).then(response => {
        console.log("查询");
        let data = response.data;
        if(data && data.length > 0){
          return true;
        }
    });
    },*/
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            updateDeposit_offer(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.open = false;
                this.getList();
              }
            });
          } else {
            addDeposit_offer(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              }
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      let inquiryNum = row.inquiryNo;
      this.$confirm('是否确认撤回报价函信息-询价函编号为"' + inquiryNum + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delDeposit_offer(ids);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        }).catch(function() {});
    },
    /** 导出按钮操作 */
    handleExport() {
      const queryParams = this.queryParams;
      this.$confirm('是否确认导出所有报价函信息-存款数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return exportDeposit_offer(queryParams);
        }).then(response => {
          this.download(response.msg);
        }).catch(function() {});
    }
  }
};
</script>
