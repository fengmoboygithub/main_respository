<template>

  <el-card>
    <el-tabs v-model="activeName">
      <el-form ref="basicInfoForm" :model="info"  label-width="100px">
        <el-row>
          <el-col :span="6">
            <el-form-item label="询价函编号" prop="inquiryNo">
              <el-input placeholder="请输入询价函编号" v-model="info.inquiryNo"  value="1" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="询价函名称" prop="inquiryName">
              <el-input placeholder="请输入询价函名称" v-model="info.inquiryName" value="1" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="存放期限" prop="limitTime">
              <el-input placeholder="请输入存放期限" v-model="info.limitTime" value="1" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="存放规模" prop="amount">
              <el-input placeholder="请输入存放规模" v-model="info.amount"  :disabled="true" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="6">
            <el-form-item label="起存日期" prop="inquiryBeginTime">
              <el-input placeholder="请输入起存日期" v-model="info.inquiryBeginTime" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="到期日期" prop="dueTime">
              <el-input placeholder="请输入到期日期" v-model="info.dueTime" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="报价开始时间" prop="quoteStart">
              <el-input placeholder="请输入报价开始时间" v-model="info.quoteStart" :disabled="true" />
            </el-form-item>
          </el-col>
          <el-col :span="6">
            <el-form-item label="报价截止时间" prop="quoteEnd">
              <el-input placeholder="请输入报价截止时间" v-model="info.quoteEnd" :disabled="true" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-col :span="6">
          <el-form-item label="报价银行" prop="bankName">
            <el-input placeholder="请输入报价银行" v-model="info.bankName" :disabled="true" />
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="合计存放规模" prop="quoteEnd">
            <el-input placeholder="请输入合计存放规模" v-model="info.sumScale" :disabled="true" />
          </el-form-item>
        </el-col>
      </el-form>

      <div class="app-container">
        <el-form :model="queryParams" ref="queryForm" :inline="true">
          <el-row>

          </el-row>
        </el-form>

        <el-row :gutter="10" class="mb8">
          <el-col :span="1.5">
            <el-button v-if="isEdit"
              type="primary"
              icon="el-icon-plus"
              size="mini"
              @click="handleAdd"
              v-hasPermi="['business:deposit_offer:edit']"
            >新增</el-button>
          </el-col>
        </el-row>

        <el-table ref="dragTable" :data="cloumns"  row-key="columnId" :max-height="tableHeight">
          <el-table-column type="selection" width="55" align="center" />
          <el-table-column label="序号" type="index" align="center" prop="uuid"/>
          <el-table-column label="id"  align="center" prop="id" v-if="show" />
          <el-table-column label="利率(%)" align="center" prop="interestRate":formatter="formatMoney" />
          <el-table-column label="最高存放规模(元)" align="center" prop="scale":formatter="formatMoney" />

          <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
            <template slot-scope="scope">

              <div  v-if="edit">
                <el-button
                  size="mini"
                  type="text"
                  icon="el-icon-edit"
                  @click="handleUpdate(scope.row, scope.$index)"
                  v-hasPermi="['business:deposit_offer:edit']"
                >修改</el-button>
                <el-button

                  size="mini"
                  type="text"
                  icon="el-icon-delete"
                  @click="handleDelete_detail(scope.row,scope.$index)"
                  v-hasPermi="['business:deposit_offer:edit']"
                >删除</el-button>
              </div>
            </template>
          </el-table-column>
        </el-table>

        <pagination
          v-show="total>0"
          :total="total"
          :page.sync="queryParams.pageNum"
          :limit.sync="queryParams.pageSize"
          @pagination="getList"
        />

        <!-- 添加或修改参数配置对话框 -->
        <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
          <el-form ref="form" :model="form":rules="rules"  label-width="80px">
            <el-form-item label="id" prop="id" hidden >
              <el-input v-model="form.id"  />
            </el-form-item>
            <el-form-item label-width="150px" label="利率(%)" prop="interestRate">
              <el-input v-model="form.interestRate" placeholder="请输入利率(%)" />
            </el-form-item>
            <el-form-item label-width="150px" label="最高存放规模(元)" prop="scale">
              <el-input v-model="form.scale" placeholder="请输入最高存放规模(元)" />
            </el-form-item>
            <!--<el-table-column prop="trainers" label="最高存放规模(元)" width="180">
              <template slot-scope="scope">
                <el-cascader
                  :options="options6"
                  :props="scale"
                  clearable
                  v-model="scope.row.scale"
                ></el-cascader>
              </template>
            </el-table-column>-->
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="addClick()">确 定</el-button>
            <el-button @click="cancel">取 消</el-button>
          </div>
        </el-dialog>
      </div>
    </el-tabs>
    <el-form label-width="100px">
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
        <el-button v-if="isEdit" type="primary" @click="submitForm(1)">保存</el-button>
        <el-button v-if="isEdit" type="primary" @click="submitForm(2)">提交</el-button>
        <el-button @click="close()">返回</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>
<script>
    import { getDeposit_offer, updateDeposit_offer } from "@/api/business/deposit_offer/deposit_offer";
    import { optionselect as getDictOptionselect } from "@/api/system/dict/type";
    import Sortable from 'sortablejs';
    export default {
        name: "deposit_offer_view",
        data() {
            //最多5位小数
            var maxFiveDecimalPlace = (rule, value, callback) => {
              if (!/^(([1-9]{1}\d*)|(0{1}))(\.\d{1,5})?$/.test(value)) {
                callback(new Error('必须为正数数字类型且最多5位小数'));
              } else {
                callback();
              }
            };

          //最多2位小数
          var maxTwoDecimalPlace = (rule, value, callback) => {
            if (!/^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/.test(value)) {
              callback(new Error('必须为正数数字类型且最多2位小数'));
            } else {
              callback();
            }
          };

            return {
                // 遮罩层
                loading: true,
                show: false,
                // 选中数组
                ids: [],
                // 非单个禁用
                single: true,
                // 非多个禁用
                multiple: true,
                // 总条数
                total: 0,
                // 字典表格数据
                dataList: [],
                // 默认字典类型
                defaultDictType: "",
                // 弹出层标题
                title: "",
                // 是否显示弹出层
                open: false,
                // 状态数据字典
                statusOptions: [],
                // 类型数据字典
                typeOptions: [],
                // 查询参数
                queryParams: {
                    pageNum: 1,
                    pageSize: 10
                },
                // 表单参数
                form: {
                  interestRate: '',
                  scale: '',
                },
                rules:{
                  interestRate: [
                    { required: true, message: '利率不能为空', trigger: 'blur' },
                    {validator: maxFiveDecimalPlace, trigger: 'blur' }
                  ],
                  scale: [
                    { required: true, message: '最高存放规模不能为空', trigger: 'blur' },
                    {validator: maxTwoDecimalPlace, trigger: 'blur' }

                  ]
                },
                // 选中选项卡的 name
                activeName: "cloum",
                // 表格的高度
                tableHeight: document.documentElement.scrollHeight - 245 + "px",
                // 表列信息
                cloumns: [],
                // 字典信息
                dictOptions: [],
                // 表详细信息
                info: {},
                edit: false,
                isEdit:true,
                currentRow: undefined // 编辑当前行
            };
        },
        created() {
          const { state } = this.$route.query;
            this.isEdit = !!Number(state)
            this.edit = !!Number(state)
        },
        beforeCreate() {
            const { id } = this.$route.query;
            if (id) {
                // 获取表详细信息
                getDeposit_offer(id).then(res => {
                    if(res.data.detailList) {
                      this.cloumns = res.data.detailList;
                    }
                    let sumScale = res.data.sumScale;
                    res.data.sumScale = this.formatNum(sumScale);
                    let amount = res.data.amount;
                    res.data.amount = this.formatNum(amount);
                    this.info = res.data;
                });
                /** 查询字典下拉列表 */
                getDictOptionselect().then(response => {
                    this.dictOptions = response.data;
                });
            }
        },

        methods: {
          formatNum(value){
            if(!value) return '';
            var intPart = Number(value).toFixed(0); //获取整数部分
            var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
            var floatPart = "00"; //预定义小数部分
            var value2Array = value.toString().split(".");
            //=2表示数据有小数位
            if(value2Array.length == 2) {
              floatPart = value2Array[1].toString(); //拿到小数部分
              if(floatPart.length == 1){
                floatPart += '0';
              }
            }
            return intPartFormat + '.' +floatPart;
          },
          formatMoney(row, column){
              let num
              if(column.property == 'scale'){
                num = row.scale;
              }else if(column.property == 'interestRate'){
                num = row.interestRate;
              }
              // 将num中的$,去掉，将num变成一个纯粹的数据格式字符串
              num = num.toString().replace(/\$|\,/g, '')
              // 如果num不是数字，则将num置0，并返回
              if (num === '' || isNaN(num)) {
                return 'Not a Number ! '
              }
              // 如果num是负数，则获取她的符号
              var sign = ''
              if (num.indexOf('-') !== -1) {
                sign = '-'
                num = num.substr(1)
              }
              // 如果存在小数点，则获取数字的小数部分
              var cents = num.indexOf('.') > 0 ? num.substr(num.indexOf('.')) : ''
              // cents = cents.length > 1 ? cents : '' // 注意：这里如果是使用change方法不断的调用，小数是输入不了的
              if(column.property == 'scale'){
                if(cents.length == 0){
                  cents = '.00'
                }else if(cents.length == 1){
                  cents += '0'
                }else if(cents.length == 2){
                  cents += '0'
                }
              }else if(column.property == 'interestRate'){
                if(cents.length == 0){
                  cents = '.00000'
                }else if(cents.length == 1){
                  cents += '0'
                }else if(cents.length == 2){
                  cents += '0000'
                }else if(cents.length == 3){
                  cents += '000'
                }else if(cents.length == 4){
                  cents += '00'
                }else if(cents.length == 5){
                  cents += '0'
                }
              }

              // 获取数字的整数数部分
              num = num.indexOf('.') > 0 ? num.substring(0, (num.indexOf('.'))) : num
              // 如果没有小数点，整数部分不能以0开头
              if (cents === '') {
                if (num.length > 1 && num.substr(0, 1) === '0') {
                  return 'Not a Number ! '
                }
              } else {
                if (num.length > 1 && num.substr(0, 1) === '0') {
                  return 'Not a Number ! '
                }
              }
              // 针对整数部分进行格式化处理，这是此方法的核心，也是稍难理解的一个地方，逆向的来思考或者采用简单的事例来实现就容易多了
              /*
                也可以这样想象，现在有一串数字字符串在你面前，如果让你给他家千分位的逗号的话，你是怎么来思考和操作的?
                字符串长度为0/1/2/3时都不用添加
                字符串长度大于3的时候，从右往左数，有三位字符就加一个逗号，然后继续往前数，直到不到往前数少于三位字符为止
               */
              for (var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
                num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3))
              }
              // 将数据（符号、整数部分、小数部分）整体组合返回
              return sign + num + cents
            },
            close(){
                this.$store.dispatch("tagsView/delView", this.$route);
                this.$router.push({ path: "/business/deposit_offer"});
            },
            /** 提交按钮 */
            submitForm(optType) {
                const basicForm = this.$refs.basicInfoForm;
                const dragTable = this.$refs.dragTable;

                const depositOfferTable = Object.assign({}, basicForm.model);
                depositOfferTable.optType = optType;
                depositOfferTable.columns = this.cloumns;
                depositOfferTable.amount = null;
                depositOfferTable.sumScale = null;
                updateDeposit_offer(depositOfferTable).then(res => {
                    this.msgSuccess(res.msg);
                    if (res.code === 200) {
                        this.edit = true;
                        this.close();
                    }
                });
            },
            /** 查询存款报价详情子列表 */
            getList() {
                this.loading = true;
                listData(this.queryParams).then(response => {
                    this.dataList = response.rows;
                    this.total = response.total;
                    this.loading = false;
                });
            },
            // 取消按钮
            cancel() {
                this.open = false;
                this.currentRow = undefined
                this.reset();
            },
            // 表单重置
            reset() {
                // this.form = {
                //     interestRate: undefined,
                //     scale: undefined,
                //     id: undefined
                // };

                this.resetForm("form");
            },
            /** 新增按钮操作 */
            handleAdd() {
                this.currentRow = undefined;
                this.reset();
                this.open = true;
                this.title = "添加报价函信息";
                // this.form.dictType = this.queryParams.dictType;
            },
            //新增方法
            addClick() {
                this.$refs["form"].validate(valid => {
                    if (valid) {
                      console.log(this.form, this.form.id)
                        if (this.currentRow != undefined) {
                            // var list = {
                            //     interestRate: this.form.interestRate,
                            //     scale: this.form.scale
                            // };
                            // this.cloumns.push(list);
                            this.$set(this.cloumns, this.currentRow, {...this.form})
                            this.msgSuccess("修改成功");
                            this.open = false;
                        } else {
                            var list = {
                                // id: 0,
                                interestRate: this.form.interestRate,
                                scale: this.form.scale
                            };
                            this.cloumns.push(list);
                            this.msgSuccess("新增成功");
                            this.open = false;
                        }
                    }
                });

            },
            //删除新增的某行数据
            handleDelete_detail( row,index) {
                this.$confirm('是否确认删除该报价单信息数据项?', "警告", {
                    confirmButtonText: "确定",
                    cancelButtonText: "取消",
                    type: "warning"
                }).then(function() {
                    return false;
                }).then(() => {
                    this.cloumns.splice(index, 1);
                    this.msgSuccess("删除成功");
                }).catch(function() {});


            },

            // 多选框选中数据
            handleSelectionChange(selection) {
                this.ids = selection.map(item => item.uuid)
                this.single = selection.length!=1
                this.multiple = !selection.length
            },
            /** 修改按钮操作 */
            handleUpdate(row, i) {
                // this.reset();
                this.form ={...row}
                this.open = true;
                this.title = "修改报价函信息";
                this.currentRow = i
                console.log(row, i)
            }
        }
    };
</script>
