<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" label-width="100px">
      <el-form-item label="询价函编号" prop="inquiryNo">
        <el-input
          v-model="queryParams.inquiryNo"
          placeholder="请输入询价函编号"
          size="small"
          style="width: 200px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="询价函名称" prop="inquiryName">
        <el-input
          v-model="queryParams.inquiryName"
          placeholder="请输入询价函名称"
          size="small"
          style="width: 200px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="起存日期" prop="beginTime">
        <el-date-picker
              v-model="queryParams.beginTime"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="起存日期"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="到期日期" prop="endTime">
        <el-date-picker
              v-model="queryParams.endTime"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="到期日期"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="报价开始时间" prop="quoteStart">
        <el-date-picker
              v-model="queryParams.quoteStart"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="报价开始时间"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="报价截止时间" prop="quoteEnd">
        <el-date-picker
              v-model="queryParams.quoteEnd"
              size="small"
              style="width: 200px"
              value-format="yyyy-MM-dd"
              type="date"
              placeholder="报价截止时间"
            ></el-date-picker>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status"  placeholder="状态" clearable size="small" style="width: 200px" >
          <el-option
            v-for="dict in statusOptions"
            :key="dict.dictValue"
            :label="dict.dictLabel"
            :value="dict.dictValue"
          />
        </el-select>
      </el-form-item>
      <el-form-item style="float:right;">
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          icon="el-icon-plus"
          size="mini"
          @click="handleAddDeposit"
          v-hasPermi="['business:deposit:add']"
        >新增</el-button>
      </el-col>
    </el-row>

    <el-table v-loading="loading" :data="depositList">
      <!-- <el-table-column type="selection" width="35" align="center"/> -->
      <el-table-column label="询价函编号" align="center" prop="inquiryNo" min-width="130%"/>
      <el-table-column label="询价函名称" align="center" prop="inquiryName"  min-width="160%"/>
      <el-table-column label="存放规模(元)" align="center" prop="amount" :formatter="currencyFormat" min-width="150%"/>
      <el-table-column label="存放期限" align="center" prop="limitTime" :formatter="limitFormat" min-width="75%"/>
      <el-table-column label="起存日期" align="center" prop="beginTime" min-width="92%"/>
      <el-table-column label="到期日期" align="center" prop="dueTime" min-width="92%"/>
      <el-table-column label="报价开始时间" align="center" prop="quoteStart" min-width="150%"/>
      <el-table-column label="报价截止时间" align="center" prop="quoteEnd" min-width="150%"/>
      <el-table-column label="状态" align="center" prop="status" :formatter="statusFormat" min-width="65%"/>
      <el-table-column label="报价结果" align="center" prop="result"  class-name="small-padding fixed-width" min-width="75%">
      <template slot-scope="scope">
        <p v-if="scope.row.status=='2'"  style="padding:0px auto;margin:0px auto;">
          <el-button
              size="mini"
              type="text"
              icon="el-icon-document"
              @click="ViewDepositDetails(scope.row)"
              v-hasPermi="['business:deposit:result']"
          >查看</el-button>
        </p>
        <p v-if="scope.row.status=='3'||scope.row.status=='5'"  style="padding:0px auto;margin:0px auto;">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="ViewDepositStatistics(scope.row)"
            v-hasPermi="['business:deposit:result']"
          >报价统计</el-button>
        </p>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" width="160">
        <template slot-scope="scope" >
          <el-button
            size="mini"
            type="text"
            icon="el-icon-view"
            @click="handleViewDeposit(scope.row)"
            v-hasPermi="['business:deposit:query']"
          >详情</el-button>

          <span v-if="scope.row.status=='0'">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-edit"
              @click="handleAddDeposit(scope.row)"
              v-hasPermi="['business:deposit:edit']"
            >编辑</el-button>
            <el-button
              size="mini"
              type="text"
              icon="el-icon-delete"
              @click="handleDelete(scope.row)"
              v-hasPermi="['business:deposit:remove']"
            >删除</el-button>
          </span>
          <span v-if="scope.row.status=='1'">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-success"
              @click="handleCheckDeposit(scope.row)"
              v-hasPermi="['business:deposit:check']"
            >复核</el-button>
            <el-button
              size="mini"
              type="text"
              icon="el-icon-refresh-left"
              @click="handleWithdrawDeposit(scope.row)"
              v-hasPermi="['business:deposit:withdraw']"
            >撤回</el-button>
          </span>
          <span v-if="scope.row.status=='2'  || scope.row.status=='3' ">
            <el-button
              size="mini"
              type="text"
              icon="el-icon-s-release"
              @click="handleCancelDeposit(scope.row)"
              v-hasPermi="['business:deposit:cancel']"
            >取消</el-button>
          </span>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

  </div>
</template>

<script>
import { listDeposit, getDeposit, delDeposit, addDeposit, updateDeposit, withdrawDeposit } from "@/api/business/deposit";

export default {
  name: "deposit",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 总条数
      total: 0,
      // 询价函表格数据
      depositList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 状态数据字典
      statusOptions: [],
      //存放期限单位字典
      limitOptions: [],
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        inquiryNo: undefined,
        inquiryName: undefined,
        beginTime: undefined,
        status: undefined,
        endTime: undefined
      },
      // 表单参数
      form: {},
    };
  }/* ,
  watch: {
    queryParams:{
      handler(val, oldVal){
        this.$nextTick(function () {
          alert(document.body.querySelector(".app-container"))
          document.parentNode.querySelector(".app-container").scrollTop = 0;
        });
      },
      deep: true//true 深度监听
    },
  } */,
  created() {
    this.getList();
    this.getDicts("busi_deposit_status").then(response => {
      this.statusOptions = response.data;
    });
    this.getDicts("busi_deposit_limit_unit").then(response => {
      this.limitOptions = response.data;
    });
  },
  methods: {
    /** 查询询价函列表 */
    getList() {
      this.loading = true;
      listDeposit(this.queryParams).then(response => {
        this.depositList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 存放期限单位字典翻译
    limitFormat(row, column) {
      return row.limitTime + this.selectDictLabel(this.limitOptions, row.limitUnit);
    },
    // 存放规模财务货币化
    currencyFormat(row, column) {
        const value = row.amount;
        if(!value) return '';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        if(value2Array.length == 2) {
          floatPart = value2Array[1].toString();
          if(floatPart.length == 1){
            floatPart += '0';
          }
        }
        return intPartFormat + '.' +floatPart;
        
    },
    // 询价函状态字典翻译
    statusFormat(row, column) {
      return this.selectDictLabel(this.statusOptions, row.status);
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!=1
      this.multiple = !selection.length
    },
    /** 新增修改按钮操作 */
    handleAddDeposit(row) {
      const id = row.id || this.ids[0];
      if(id){
        this.$router.push({ path: "/deposit/edit", query: { id: id}});
      }else{
        this.$router.push({ path: "/deposit/add", query: { id: id}});
      }
    },
    /** 详情操作 */
    handleViewDeposit(row) {
      const id = row.id || this.ids[0];
      this.$router.push({ path: "/deposit/query", query: { id: id, checked: 0}});
    },
    /** 报价结果 */
    ViewDepositDetails(row) {
      const id = row.id || this.ids[0];
      const fpath = '/business/deposit';
      this.$router.push({ path: "/audit/result", query: { id: id, fpath:fpath}});
    },
    /** 报价结果统计 */
    ViewDepositStatistics(row) {
      const id = row.id || this.ids[0];
      const fpath = '/business/deposit';
      this.$router.push({ path: "/audit/Statistics", query: { id: id, fpath: fpath}});
    },
    /** 复核操作 */
    handleCheckDeposit(row) {
      const id = row.id || this.ids[0];
      this.$router.push({ path: "/deposit/check", query: { id: id, checked: 1}});
    },
    /** 取消询价函操作 */
    handleCancelDeposit(row) {
      const id = row.id || this.ids[0];
      this.$router.push({ path: "/deposit/cancel", query: { id: id, checked: 2}});
    },
    /** 提交按钮 */
    submitForm: function() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != undefined) {
            updatePost(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.getList();
              }
            });
          } else {
            addPost(this.form).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.getList();
              }
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const depositIds = row.id;
      const inquiryNo = row.inquiryNo;
      this.$confirm('是否确认删除询价函编号为"' + inquiryNo + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return delDeposit(depositIds,inquiryNo);
        }).then(() => {
          this.getList();
          this.msgSuccess("删除成功");
        }).catch(function() {
          this.msgError('删除失败');
        });
    },
    /** 撤回按钮操作 */
    handleWithdrawDeposit(row) {
      const depositIds = row.id;
      const inquiryNo = row.inquiryNo;
      this.$confirm('是否确认撤回询价函编号为"' + inquiryNo + '"的数据项?', "警告", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(function() {
          return withdrawDeposit(depositIds,inquiryNo);
        }).then(() => {
          this.getList();
          this.msgSuccess("撤回成功");
        }).catch(function() {
          this.msgError('撤回失败');
        });
    }


  }
};
</script>
