<template>
  <el-card>
    <el-form ref="form"  :model="deposit" :rules="rules" label-width="130px">
      <el-row>
        <el-col :span="8">
          <el-form-item label="询价函编号" prop="inquiryNo" >
            <el-input v-model="deposit.inquiryNo" placeholder="系统自动生成" readonly="readonly" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="询价函名称" prop="inquiryName">
            <el-input v-model="deposit.inquiryName" placeholder="请输入询价函名称" maxlength="100"/>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="存放规模(元)" prop="amount">
            <el-input v-model="deposit.amount" placeholder="请输入存放规模(元)" maxlength="100"/>
          </el-form-item>
        </el-col>
      </el-row> 

      <el-row>
        <el-col :span="8">
          <el-form-item label="起存日期" prop="beginTime">
            <el-date-picker
              v-model="deposit.beginTime"
              size="small"
              style="width: 100%"
              value-format="yyyy-MM-dd"
              format="yyyy-MM-dd"
              type="date"
              placeholder="请输入起存日期"
              :picker-options="options"
               @change="calDueTime"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="存放期限" prop="limitTime">
            <el-input v-model="deposit.limitTime" placeholder="请输入存放期限" style="width:70%;" @change="calDueTime" />&nbsp;
            <el-select v-model="deposit.limitUnit"  placeholder="请输入存放期限单位" style="width:26%;float:right;" @change="calDueTime">
              <el-option
                v-for="dict in limitStatusOptions"
                :key="dict.dictValue"
                :label="dict.dictLabel"
                :value="dict.dictValue"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="到期日期" prop="dueTime">
            <el-input v-model="deposit.dueTime" placeholder="到期日期" style="width:100%;" readonly="readonly" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="报价截止时间" prop="quoteEnd">
            <el-date-picker
                  v-model="deposit.quoteEnd"
                  size="small"
                  style="width: 100%"
                  value-format="yyyy-MM-dd HH:mm:ss"
                  format="yyyy-MM-dd HH:mm:ss"
                  type="datetime"
                  placeholder="报价截止时间"
                  :picker-options="options"
                  @input="datetimeChange"
                ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="16">
        </el-col>
      </el-row>
      <el-row> 
        <el-col :span="24">
          <el-form-item label="发送银行" prop="bankIds">
              <el-checkbox v-for="bank in banks" :key="bank.id" :checked="bank.isActive" :label="bank.name" @change="selectedBanks(bank)"  v-model="bank.isActive">
              </el-checkbox>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="短信内容" prop="messageContent">
            <el-input v-model="deposit.messageContent" type="textarea"  placeholder="请输入短信内容" readonly="readonly"/>
          </el-form-item>
        </el-col>
      </el-row>
        <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;">
          <el-button type="primary" @click="submitForm(0)">保 存</el-button>
          <el-button type="primary" @click="submitForm(1)">发 布</el-button>
          <el-button type="primary" @click="close()">返 回</el-button>
        </el-form-item>
      </el-form>

  </el-card>
</template>
<script>
import { getDeposit, addDeposit, updateDeposit, getMobileMessage, listBanks, calculateDepositDueTime } from "@/api/business/deposit";
import { formatDate } from '@/utils/date';

export default {
  name: "DepositEdit",
  components: {
  },
  data() {
    var isNumber = (rule, value, callback) => {
      let numberReg = /^(\-|\+)?\d+(\.\d+)?$/
      if (value !== '') {
          if (!numberReg.test(value)) {
              callback(new Error('请输入数字'))
          } else {
              callback()
          }
      } else {
          callback(new Error('请输入数字'))
      }
    };
    var isNumberNotMust = (rule, value, callback) => {
      if(value){
        let numberReg = /^(\-|\+)?\d+(\.\d+)?$/
        let degReg = /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/

        if (value !== '') {
            if (!numberReg.test(value)) {
                callback(new Error('请输入数字'))
            } else if(!degReg.test(value)){
              callback(new Error('请输入有效数字,且最多两位小数'));
            }else {
                callback()
            }
        } else {
            callback(new Error('请输入数字'))
        }
      }else{
        callback();
      }
    };

    //自动检验数值的范围
    var  checkNumberRange = (rule, value, callback) => {
      if(value) {
        if((value < 0 || value > 999999999999.99)){
          callback(new Error('请输入[0.00,999999999999.99]之间的数字'));
        }else{
        callback();
      }
      }else{
        callback();
      }
    }

    //自动检验数值的范围
    var  checkNumberRange999 = (rule, value, callback) => {
      if(!value || (value < 1 || value > 999)){
        callback(new Error('请输入[1,999]之间的数字'));
      } else {
        callback();
      }
    }
    
    //最多6位小数
    var maxSixDecimalPlace = (rule, value, callback) => {
      if (!/^[0-9]+([.]{1}[0-9]{6})?$/.test(value)) {
        callback(new Error('最多6位小数'));
      } else {
        callback();
      }
    };
    
    //两位小数验证
    var MaxTwoDecimalPlace = (rule, value, callback) => {
      if(!value){
        if (/^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/.test(value)) {
          callback(new Error('最多两位小数'));
        } else {
          callback();
        }
      }else{
        callback();
      }
    };
    
    var noEmpty = (rule, value, callback) => {
      if(!value || Object.keys(value).length==0){
        callback(new Error('请选择银行'));
      }else{
         callback();
      }
    };

    //验证是否整数,非必填
    var isIntegerNotMust = (rule, value, callback) => {
      if (!value) {
        callback();
      }
      setTimeout(() => {
        if (!Number(value)) {
          callback(new Error('请输入正整数'));
        } else {
          const re = /^[0-9]*[1-9][0-9]*$/;
          const rsCheck = re.test(value);
          if (!rsCheck) {
            callback(new Error('请输入正整数'));
          } else {
            callback();
          }
        }
      }, 1000);
    };
    
    //验证是否整
    var isInteger = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('输入不可以为空'));
      }
      setTimeout(() => {
        if (!Number(value)) {
          callback(new Error('请输入正整数'));
        } else {
          const re = /^[0-9]*[1-9][0-9]*$/;
          const rsCheck = re.test(value);
          if (!rsCheck) {
            callback(new Error('请输入正整数'));
          } else {
            callback();
          }
        }
      }, 0);
    };
    
    var specialChar = (rule, value, callback) => {
      if(value==''||value==undefined||value==null){
        callback();
      } else {
        if (value.indexOf('｛询价函期号｝')==-1){
          callback(new Error('短信模板必须包含“｛询价函期号｝”字样'));
        } else {
          callback();
        }
      }
    };

    const validateDate = (rule, value, callback) => {
      if (value) {
        if (parseInt(formatDate(new Date(value), "yyyyMMdd")) < parseInt(formatDate(new Date(), "yyyyMMdd"))) {
          callback(new Error('不能小于当前日期'))
        }else if (formatDate(new Date(value), "yyyy-MM-dd HH:mm:ss") < formatDate(new Date(), "yyyy-MM-dd HH:mm:ss")) {
          callback(new Error('不能小于当前时间'))
        }else if(this.deposit.beginTime){
          if(parseInt(formatDate(new Date(value), "yyyyMMdd")) > parseInt(formatDate(new Date(this.deposit.beginTime), "yyyyMMdd"))){
            callback(new Error('不能大于起存日期'))
          }else {
          callback()
        }
        }else {
          callback()
        }
      } else {
        callback()
      }
    };

    const validateDate2 = (rule, value, callback) => {
      if (value) {
        if (parseInt(formatDate(new Date(value), "yyyyMMdd")) < parseInt(formatDate(new Date(), "yyyyMMdd"))) {
          callback(new Error('不能小于当前日期'))
        }else if(this.deposit.quoteEnd){
          if(parseInt(formatDate(new Date(value), "yyyyMMdd")) < parseInt(formatDate(new Date(this.deposit.quoteEnd), "yyyyMMdd"))){
            callback(new Error('不能小于报价截止时间'))
          }else {
          callback()
          }
        }else {
          callback()
        }
      } else {
        callback()
      }
    };

    return {
      options: {
        disabledDate(time) {
          return time.getTime() <= Date.now() - 1 * 24 * 3600 * 1000;
        }
      }, 
      // 字典信息
      limitStatusOptions: [],
      // 表详细信息
      deposit: {
         limitUnit: '0',
         messageContent: '',
         bankIds: '',
         quoteEnd: '',
         beginTime: '',
         dueTime: ''
      },
      
      selectedBankIds: [],
      //银行列表
      banks:{},
      // 表单校验
      rules: {
        inquiryName: [
          { required: true, message: "询价函名称不能为空", trigger: "blur" }
        ],
        beginTime: [
          { required: true, message: "起存日期不能为空", trigger: "blur" },
          { validator: validateDate2, trigger: 'blur'}
        ],
        endTime: [
          { required: true, message: "到期日期不能为空", trigger: "blur" }
        ],
        limitTime: [
          { required: true, message: "存放期限不能为空", trigger: "blur" },
          { validator: isNumber, trigger: 'blur' },
          { validator: checkNumberRange999, trigger: 'blur' },
          { validator: isInteger, trigger: 'blur' }
        ],
        limitUnit: [
          { required: true, message: "存放期限单位不能为空", trigger: "blur" }
        ],
        amount: [
          { validator: isNumberNotMust, trigger: 'blur' },
          { validator: checkNumberRange, trigger: 'blur' }
        ],
        quoteEnd: [
          { required: true, message: "报价截止时间不能为空", trigger: "blur" },
          { validator: validateDate, trigger: 'blur'}
        ],
        bankIds: [
          { validator: noEmpty, trigger: 'blur' }
        ],
        messageContent: [
          { required: true, message: "短信内容不能为空", trigger: "blur" },
          { validator: specialChar, trigger: 'blur' }
        ]
      }
    };
  },
  beforeCreate() {
    /** 查询字典下拉列表 */
    this.getDicts("busi_deposit_limit_unit").then(response => {
      this.limitStatusOptions = response.data;
    });

  },
  created(){
    this.getDetail();
  },
  watch: {
    "$route"(val,oldval){
      if(val.meta.title.indexOf('询价函')!=-1){
        this.getDetail();
      }
    }
  },
  methods: {
    datetimeChange(e){
      let _this =this
      _this.deposit.quoteEnd = e
      _this.$forceUpdate();
    },

    calDueTime(){
      let _this =this
      let bt = this.deposit.beginTime;
      let lt = this.deposit.limitTime;
      let lu = this.deposit.limitUnit;
      if(bt && lt && lu){
        calculateDepositDueTime(bt, lt, lu).then(response => {
          if (response.code === 200) {
            this.deposit.dueTime = response.data.dueTime;
          }else{
            this.msgError("到期日期计算异常");
          }
        });
      }
      _this.$forceUpdate();
    },
    
    selectedBanks(value){
      if(value){
        var flg = false;
        for(var i=0; i<this.selectedBankIds.length; i++){
          if(this.selectedBankIds[i] == value.id){
            flg = true;
            if(!value.isActive){
              this.selectedBankIds.splice(i,1);
              break;
            }
          }
        }
        if(!flg){
          if(value.isActive){
              this.selectedBankIds.push(value.id);
            }
        }
      }
      
      this.deposit.bankIds = this.selectedBankIds.join(',');
      this.$forceUpdate();
    },

    /** 关闭按钮 */
    close() {
      this.$store.dispatch("tagsView/delView", this.$route);
      this.$router.push({ path: "/business/deposit"})
    },
    
    getDetail() {
    const { id } = this.$route.query;
    if (id) {
      // 获取表详细信息
      getDeposit(id).then(res => {
         this.deposit = res.data;
         this.deposit.quoteEnd = new Date(res.data.quoteEnd);
         //this.$set(this.deposit,'quoteEnd', res.data.quoteEnd);
        //获取银行列表
        listBanks().then(res => {
          this.banks = res.data;
          if(this.deposit.bankIds){
            var bs = this.deposit.bankIds.split(',');
            this.selectedBankIds = this.deposit.bankIds.split(',');
            this.banks.map(item => {
              bs.forEach(function(value,key,arr) {
                if(value == item.id){
                  item.isActive = true;
                }
              });
            });
          }
        });
      });
    }else{
      //获取银行列表
      listBanks().then(res => {
        this.banks = res.data;
        this.banks.map(item => {
          item.isActive = true;
          this.selectedBankIds.push(item.id);
          this.deposit.bankIds = this.selectedBankIds.join(',');
        });
      });
      
    }
    // 获取手机短信模板信息
    getMobileMessage().then(res => {
      if (res.code === 200) {
        this.deposit.messageContent = res.data.constVal;
      }
    });
  },
    /** 提交按钮 */
    submitForm(val) {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.deposit.status = val;
          this.deposit.quoteEnd = formatDate(new Date(this.deposit.quoteEnd), "yyyy-MM-dd HH:mm:ss");
          this.deposit.beginTime = formatDate(new Date(this.deposit.beginTime), "yyyy-MM-dd");
          if (this.deposit.id != undefined) {
            updateDeposit(this.deposit).then(response => {
              if (response.code === 200) {
                this.msgSuccess("修改成功");
                this.close();
              }
            });
          } else {
            addDeposit(this.deposit).then(response => {
              if (response.code === 200) {
                this.msgSuccess("新增成功");
                this.close();
              }
            });
          }
        }
      });
    }
  }
  /* ,
  watch: {//拉屎放屁
    'deposit': function () {
      this.$nextTick(function () {
        var bs = this.deposit.bankIds.split(',');
        this.banks.map(item => {
          bs.forEach(function(value,key,arr) {
            if(value == item.id){
              this.$set(this.bids, item.id, item.name);
            }
          });
        });
      })
    }
  } */

}
</script>