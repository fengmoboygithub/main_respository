<template>
  <el-card style='margin: 25px 30px 0 25px;width=100%;'>
    <el-form ref="form" :model="form" label-width="150px" >
      
      <el-row >
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="询价函编号：" prop="inquiryNo">{{ form.inquiryNo }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="询价函名称："  prop="inquiryName">{{ form.inquiryName }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="存放规模(元)："  prop="amount">{{currencyFormat(form)}}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="起存日期：" prop="beginTime">{{ form.beginTime }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="存放期限：" prop="limitTime">{{ limitFormat(form) }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="到期日期：" prop="dueTime">{{ form.dueTime }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-right:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="报价开始时间：" prop="quoteStart">{{ form.quoteStart }}</el-form-item>
        </el-col>
        <el-col :span="12" style='border-bottom:1px dotted Gainsboro;border-left:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="报价截止时间：" prop="quoteEnd">{{ form.quoteEnd }}</el-form-item>
        </el-col>
        <el-col :span="24" style='border-bottom:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="发送银行：" prop="bankIds">
            <span v-for="bank in banks" :key="bank.id">
              <span v-if="bank.isActive">
                {{bank.name}}&nbsp;&nbsp;
              </span>
            </span>
          </el-form-item>
        </el-col>
        <el-col :span="24" style='border-bottom:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="短信内容：" prop="messageContent">{{ form.messageContent }}</el-form-item>
        </el-col>
        <el-col :span="24" style='border-bottom:1px dotted Gainsboro;margin:10px 0 10px 0;'>
          <el-form-item label="状态：" prop="status">{{ statusFormat(form) }}</el-form-item>
        </el-col>
        <span v-if="ckd=='2'">
          <el-col :span="24" style='border-bottom:1px dotted Gainsboro;margin:10px 0 10px 0;'>
            <el-form-item label="备注" prop="remark">
              <el-input v-model="form.remark" type="textarea"  placeholder="请输入备注" />
            </el-form-item>
          </el-col>
        </span>
        <span v-if="form.status==4">
          <el-col :span="24" style='border-bottom:1px dotted Gainsboro;margin:10px 0 10px 0;'>
            <el-form-item label="备注：" prop="remark">
              {{ form.remark }}
            </el-form-item>
          </el-col>
        </span>
      </el-row>
      <el-form-item style="text-align: center;margin-left:-100px;margin-top:10px;margin:10px 0 10px 0;">
        <span v-if="ckd==1">
          <el-button type="primary" @click="submitForm(2)">审核通过</el-button>
          <el-button type="primary" @click="submitForm(0)">审核不通过</el-button> &nbsp;
        </span>
        <span v-if="ckd==2">
          <el-button type="primary" @click="submitForm(4)">确认取消</el-button>
        </span>
        <el-button type="primary" @click="close()">关 闭</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
import { getDeposit, checkDeposit, cancelDeposit, listBanks } from "@/api/business/deposit";

export default {
  name: "DepositView",
  components: {},
  data() {

    return {
      fid: '',
      // 表详细信息
      form: {id: '', inquiryNo: '',  remark:'', status:''},
      ckd: '0',
      selectedBankIds: [],
      banks: {},
      // 状态数据字典
      statusOptions: [],
      //存放期限单位字典
      limitOptions: []
    };
  },
  created(){
    this.getDetail();
  },
  beforeCreate() {
    const { checked } = this.$route.query;
    this.getDicts("busi_deposit_status").then(response => {
      this.statusOptions = response.data;
    });

    this.getDicts("busi_deposit_limit_unit").then(response => {
      this.limitOptions = response.data;
    });
  },
  watch: {
    "$route"(val,oldval){
      if(val.meta.title=='询价函详情'){
        this.getDetail();
      }
    }
  },
  methods: {
    // 存放规模财务货币化
    currencyFormat(form) {
        const value = form.amount;
        if(!value) return '';
        var intPart = Number(value).toFixed(0); //获取整数部分
        var intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); //将整数部分逢三一断
        var floatPart = "00"; //预定义小数部分
        var value2Array = value.split(".");
        //=2表示数据有小数位
        if(value2Array.length == 2) {
          floatPart = value2Array[1].toString(); //拿到小数部分
          if(floatPart.length == 1){
            floatPart += '0';
          }
        }
        return intPartFormat + '.' +floatPart;
    },
    /** 关闭按钮 */
    close() {
      this.$store.dispatch("tagsView/delView", this.$route);
      this.$router.push({ path: "/business/deposit" });
    },

    // 存放期限单位字典翻译
    limitFormat(row, column) {
      return row.limitTime + this.selectDictLabel(this.limitOptions, row.limitUnit);
    },
    // 询价函状态字典翻译
    statusFormat(row, column) {
      return this.selectDictLabel(this.statusOptions, row.status);
    },
    getDetail(){
      const { id } = this.$route.query;
      const { checked } = this.$route.query;
      this.ckd = checked;
      
      if (id) {
        // 获取表详细信息
        getDeposit(id).then(ress => {
          this.form = ress.data;
          //获取银行列表
          listBanks().then(res => {
            this.banks = res.data;
            if(this.form.bankIds){
              var bs = this.form.bankIds.split(',');
              this.selectedBankIds = this.form.bankIds.split(',');
              this.banks.map(item => {
                bs.forEach(function(value,key,arr) {
                  if(value == item.id){
                    item.isActive = true;
                  }
                });
              });
            }
          });
        });

      }
    },
    /** 提交按钮 */
    submitForm(val) {
      var resultmsg = '';
      if(val == 4){
        resultmsg = '取消';
       if(this.form.remark==undefined || this.form.remark==null || this.form.remark==''){
        this.msgError("备注不能为空");
        return;
       }
      }else if(val == 2){
        resultmsg = '审核通过';
      }else{
        resultmsg = '审核不通过';
      }
      //this.form.status = val;
      const did = this.form.id;
      const dremark = this.form.remark;
      const inquiryNo = this.form.inquiryNo;
      const dstatus = val;
      this.$confirm('是否确认'+resultmsg+'询价函编号为"' + this.form.inquiryNo + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        if(val == 4){
          return cancelDeposit(did, dremark, dstatus,inquiryNo);
        }else{
          return checkDeposit(did, dstatus,inquiryNo);
        }
      }).then(() => {
        this.msgSuccess(resultmsg+"成功");
        this.close();
      }).catch(function() {
        this.msgError(resultmsg+"失败");
      });

    }
  }
};
</script>