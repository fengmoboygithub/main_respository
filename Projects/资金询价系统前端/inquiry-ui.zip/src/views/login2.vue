<template>
  <div class="login">
    <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form">
      <div style="width:100%;text-align: center;"><span class="title">用户登录</span></div>
      <h3></h3>
      <!--<span class="little-title">资金询价系统</span>-->
      <div style="height: 30px"></div>
      <el-form-item prop="username">
        <el-input v-model="loginForm.username" type="text" auto-complete="off" placeholder="请输入用户名">
          <svg-icon slot="prefix" icon-class="user-white" class="el-input__icon input-icon" />
        </el-input>
      </el-form-item>
      <el-form-item prop="password">
        <el-input
          v-model="loginForm.password"
          type="password"
          auto-complete="off"
          placeholder="请输入密码"
          @keyup.enter.native="handleLogin"
        >
          <svg-icon slot="prefix" icon-class="password" class="el-input__icon input-icon" />
        </el-input>
      </el-form-item>
      <el-form-item prop="code">
        <el-input
          v-model="loginForm.code"
          auto-complete="off"
          placeholder="请输入手机验证码"
          style="width: 14.452vw"
          @keyup.enter.native="handleLogin"
        >
          <svg-icon slot="prefix" icon-class="validCode" class="el-input__icon input-icon" />
        </el-input>
        <el-button
            :sended="sended"
            size="medium"
            type="success"
            style="width:8vw;margin-top: 0vh;margin-left: 10px;"
            @click.native.prevent="sendcode"
            v-if="!sended"
          >
            获取验证码
          </el-button>
          <el-button
            :sended="sended"
            size="medium"
            type="success"
            style="width:8vw;margin-top: 0vh;margin-left: 10px;"
            v-if="sended"
          >
            {{btntxt}}
          </el-button>
      </el-form-item>
      <el-checkbox v-model="loginForm.rememberMe" style="margin:5px 0px 25px 0px;">记住密码</el-checkbox>
      <el-form-item>
        <el-button
          :loading="loading"
          size="medium"
          type="primary"
          style="width:100%;"
          @click.native.prevent="handleLogin"
        >
          <span style="font-size: 18px" v-if="!loading">登 录</span>
          <span style="font-size: 18px" v-else>登 录 中...</span>
        </el-button>
      </el-form-item>
    </el-form>
    <!--  底部  -->
    <div class="el-login-footer">
      <span>Copyright © 2020-2021 http://www.otc-tech.cn All Rights Reserved.</span>
    </div>
  </div>
</template>

<script>
import { getCodeImg, sendsms} from "@/api/login";
import Cookies from "js-cookie";
import { encrypt, decrypt } from '@/utils/jsencrypt'

export default {
  name: "Login",
  data() {
    return {
      codeUrl: "",
      cookiePassword: "",
      loginForm: {
        username: "",
        password: "",
        rememberMe: false,
        code: "",
        uuid: ""
      },
      loginRules: {
        username: [
          { required: true, trigger: "blur", message: "用户名不能为空" }
        ],
        password: [
          { required: true, trigger: "blur", message: "密码不能为空" }
        ]
      },
      loading: false,
      redirect: undefined,
      sended: false,
      time: 0,
      btntxt: "重新发送"
    };
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect;
      },
      immediate: true
    }
  },
  created() {
    this.getCode();
    this.getCookie();
  },
  methods: {
    getCode() {
      getCodeImg().then(res => {
        //this.codeUrl = "data:image/gif;base64," + res.img;
        this.loginForm.uuid = res.uuid;
      });
    },
    //手机验证发送验证码
    sendcode() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          const username = this.loginForm.username;
          const password = this.loginForm.password;
          const uuid = this.loginForm.uuid;

          sendsms(username, password, uuid).then(res => {
            console.log(res);
          });

          this.time = 60;
          this.sended = true;
          this.timer();

          // this.$store
          //   .dispatch("Login", this.loginForm)
          //   .then(() => {
          //     this.$router.push({ path: this.redirect || "/" });
          //   })
          //   .catch(() => {
          //     this.loading = false;
          //     this.getCode();
          //   });
        }
      });
    },
    //60S倒计时
    timer() {
      if (this.time > 0) {
          this.time--;
          this.btntxt = this.time + "s后重新获取";
          setTimeout(this.timer, 1000);
      } else {
          this.time = 0;
          this.btntxt = "获取验证码";
          this.sended = false;
      }
    },
    getCookie() {
      const username = Cookies.get("username");
      const password = Cookies.get("password");
      const rememberMe = Cookies.get('rememberMe')
      this.loginForm = {
        username: username === undefined ? this.loginForm.username : username,
        password: password === undefined ? this.loginForm.password : decrypt(password),
        rememberMe: rememberMe === undefined ? false : Boolean(rememberMe)
      };
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true;
          if (this.loginForm.rememberMe) {
            Cookies.set("username", this.loginForm.username, { expires: 30 });
            Cookies.set("password", encrypt(this.loginForm.password), { expires: 30 });
            Cookies.set('rememberMe', this.loginForm.rememberMe, { expires: 30 });
          } else {
            Cookies.remove("username");
            Cookies.remove("password");
            Cookies.remove('rememberMe');
          }
          this.$store
            .dispatch("LoginBank", this.loginForm)
            .then(() => {
              this.$router.push({ path: this.redirect || "/" });
            })
            .catch(() => {
              this.loading = false;
              this.getCode();
            });
        }
      });
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss">
.login {
  /*display: flex;*/
  /*justify-content: center;*/
  /*align-items: center;*/
  height: 100%;
  background-image: url("../assets/image/login-background.png");
  background-size: cover;
}
.title {
  margin: 0px auto 30px auto;
  padding: 25px auto 5px auto;
  text-align: center;
  color: #2739b4;
  font-size: 42px;
}

.little-title{
  /*margin: 0px auto 30px auto;*/
  text-align: left;
  color: #2739b4;
  font-size: 24px;
}
.login-form {
  position: absolute;
  /*left: 1080px;*/
  /*top: 190px;*/
  min-width: 392px;
  min-height: 400px;
  margin: 20.33vh auto auto 64.07vw;
  height: 53.5vh; //500px
  border-radius: 6px;
  background: #ffffff;
  width: 29.07vw; //490 px
  padding: 2.675vh 1.483vw 0.535vh 2.729vw;
  /*padding-left: 42px;*/
  .el-form-item__error{
    color:#ea6c52;
  }
  .el-input {
    margin:0 auto;
    height: 4.922vh;
    width: 24.086vw;
    ::-webkit-input-placeholder {
      font-size: 16px;
    }
    input {
      height: 4.922vh;
    }
  }
  .input-icon {
    height: 4.922vh;
    width: 0.949vw;
    margin-left: 0.119vw;
  }
  .el-button{
    height: 4.922vh;
    width: 24.086vw;
    margin-top: 1.284vh;
  }
}
.login-tip {
  font-size: 13px;
  text-align: center;
  color: #bfbfbf;
}
.login-code {
  width: 7.23vw;
  height: 4.922vh;
  float: right;
  padding-right: 8vw;
  img {
    cursor: pointer;
    vertical-align: middle;
  }
}
.el-login-footer {
  height: 40px;
  line-height: 40px;
  position: fixed;
  bottom: 0;
  width: 100%;
  text-align: center;
  color: #fff;
  font-family: Arial;
  font-size: 12px;
  letter-spacing: 1px;
}
</style>
