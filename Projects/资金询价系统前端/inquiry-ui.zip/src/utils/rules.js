let FormValidate = (function () {
  function FormValidate () {}
  // From表单验证规则  可用于公用的校验部分
  FormValidate.Form = function () {
    return {
      isNumber(rule, value, callback){
        let numberReg = /^(\-|\+)?\d+(\.\d+)?$/
        if (value !== '') {
            if (!numberReg.test(value)) {
                callback(new Error('请输入数字'))
            } else {
                callback()
            }
        } else {
            callback(new Error('请输入数字'))
        }
      },

      //自动检验数值的范围
      checkNumberRange(rule, value, callback){
        if(!value || (value < 0 || value > 999999999999.99)){
          callback(new Error('请输入[0,999999999999.99]之间的数字'));
        } else {
          callback();
        }
      },
  
      //自动检验数值的范围
      checkNumberRange999(rule, value, callback){
        if(!value || (value < 1 || value > 999)){
          callback(new Error('请输入[1,999]之间的数字'));
        } else {
          callback();
        }
      },
      
      //最多6位小数
      maxSixDecimalPlace(rule, value, callback){
        if (!/^[0-9]+([.]{1}[0-9]{6})?$/.test(value)) {
          callback(new Error('最多6位小数'));
        } else {
          callback();
        }
      },
      
      //两位小数验证
      MaxTwoDecimalPlace(rule, value, callback){
        if (!/(^[1-9]([0-9]+)?(\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\.[0-9]([0-9])?$)/.test(value)) {
          callback(new Error('最多两位小数'));
        } else {
          callback();
        }
      },
      
      noEmpty(rule, value, callback){
        if(!value || Object.keys(value).length==0){
          callback(new Error('请选择银行'));
        }else{
           callback();
        }
      },
  
      //验证是否整数,非必填
      isIntegerNotMust(rule, value, callback){
        if (!value) {
          callback();
        }
        setTimeout(()=>{
          if (!Number(value)) {
            callback(new Error('请输入正整数'));
          } else {
            re = /^[0-9]*[1-9][0-9]*$/;
            rsCheck = re.test(value);
            if (!rsCheck) {
              callback(new Error('请输入正整数'));
            } else {
              callback();
            }
          }
        }, 1000);
      },
      
      //验证是否整
      isInteger(rule, value, callback){
        if (!value) {
          return callback(new Error('输入不可以为空'));
        }
        setTimeout(()=>{
          if (!Number(value)) {
            callback(new Error('请输入正整数'));
          } else {
            re = /^[0-9]*[1-9][0-9]*$/;
            rsCheck = re.test(value);
            if (!rsCheck) {
              callback(new Error('请输入正整数'));
            } else {
              callback();
            }
          }
        }, 0);
      },
      
      specialChar(rule, value, callback){
        if(value==''||value==undefined||value==null){
          callback();
        } else {
          if (value.indexOf('｛询价函期号｝')==-1){
            callback(new Error('短信模板必须包含“｛询价函期号｝”字样'));
          } else {
            callback();
          }
        }
      },
  
      validateDate(rule, value, callback){
        if (value) {
          if (formatDate(new Date(value), "yyyy-MM-dd") < formatDate(new Date(), "yyyy-MM-dd")) {
            callback(new Error('不能小于当前时间'))
          }else if (formatDate(new Date(value), "yyyy-MM-dd HH:mm:ss") < formatDate(new Date(), "yyyy-MM-dd HH:mm:ss")) {
            callback(new Error('不能小于当前时间'))
          }   else if(this.deposit.beginTime){
            if(formatDate(new Date(value), "yyyy-MM-dd") >= formatDate(new Date(this.deposit.beginTime), "yyyy-MM-dd")){
              callback(new Error('不能大于起存日期'))
            }else {
            callback()
          }
          }else {
            callback()
          }
        } else {
          callback()
        }
      },
  
      validateDate2(rule, value, callback){
        if (value) {
          if (formatDate(new Date(value), "yyyy-MM-dd") < formatDate(new Date(), "yyyy-MM-dd")) {
            callback(new Error('不能小于当前日期'))
          }else if (formatDate(new Date(value), "yyyy-MM-dd HH:mm:ss") < formatDate(new Date(), "yyyy-MM-dd HH:mm:ss")) {
            callback(new Error('不能小于当前时间'))
          } else if(this.deposit.quoteEnd){
            if(formatDate(new Date(value), "yyyy-MM-dd") < formatDate(new Date(this.deposit.quoteEnd), "yyyy-MM-dd")){
              callback(new Error('不能小于报价截止时间'))
            }else {
            callback()
            }
          }else {
            callback()
          }
        } else {
          callback()
        }
      }

    }
  }

  return FormValidate
}())

exports.FormValidate = FormValidate