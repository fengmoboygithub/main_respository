<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default  {
  name:  'App'
  /* ,
  watch:{
    $route:{
      handler(val,oldval){
        if(val == oldval){
          this.created();
        }
      },
      // 全局深度观察监听
      deep: true
    }
  } */
}
</script>
