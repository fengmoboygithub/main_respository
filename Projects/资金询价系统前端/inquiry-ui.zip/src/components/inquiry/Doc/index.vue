<template>
  <div>
    <svg-icon icon-class="question" @click="goto"/>
  </div>
</template>

<script>
export default {
  name: 'InquiryDoc',
  data() {
    return {
      url: 'http://doc.inquiry.vip/inquiry-vue'
    }
  },
  methods: {
    goto() {
      window.open(this.url)
    }
  }
}
</script>