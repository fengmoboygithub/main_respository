![效果图](https://github.com/caoyu48/vue-g6-editor/blob/master/1.gif)
# vue-g6-editor

demo地址：http://62.234.69.136/
G6文档   https://www.yuque.com/antv/g6

这个是个基于阿里G6制作的modelFlow组件 g6版本为3.0，UI部分用了elementUI。
由于公司需要，需要一个模型流程图编辑器，本来g6-editor是个不错的选择，但是调研之后发现
g6-editor不开源，不得商用。嗝屁，只能自己尝试着用g6实现一个editor。代码写的比较丑，仅做参考使用，不喜勿喷~。




