import G6Editor from './components/G6Editor'
G6Editor.install = function (Vue) {
    Vue.component(G6Editor.name, G6Editor)
}

export default G6Editor