# 流程图开发

先上效果图：
 ![my](https://github.com/coffee67/flow/blob/master/flow.jpg)
 
 工具：jsPlumb.js   ，     UI库：ElementUI
