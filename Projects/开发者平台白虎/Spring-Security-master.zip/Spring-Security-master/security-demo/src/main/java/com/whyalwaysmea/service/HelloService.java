package com.whyalwaysmea.service;

/**
 * @Author: HanLong
 * @Date: Create in 2018/3/16 20:50
 * @Description:
 */
public interface HelloService {

    String greeting(String name);
}
