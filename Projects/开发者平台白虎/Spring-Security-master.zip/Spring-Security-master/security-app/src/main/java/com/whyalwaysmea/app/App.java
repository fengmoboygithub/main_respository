package com.whyalwaysmea.app;

/**
 * @Author: HanLong
 * @Date: Create in 2018/3/27 21:55
 * @Description:
 */
public class App {
}
