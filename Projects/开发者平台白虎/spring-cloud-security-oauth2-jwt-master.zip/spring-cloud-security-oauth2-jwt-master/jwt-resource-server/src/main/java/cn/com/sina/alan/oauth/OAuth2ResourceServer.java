package cn.com.sina.alan.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by on 2017.03.08.
 */
@SpringBootApplication
public class OAuth2ResourceServer {

    public static void main(String[] args) {
        SpringApplication.run(OAuth2ResourceServer.class, args);
    }
}
