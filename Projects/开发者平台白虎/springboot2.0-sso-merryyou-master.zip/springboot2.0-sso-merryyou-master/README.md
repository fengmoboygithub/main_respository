## springboot2.0-sso-merryyou
- [SpringBott 1.5.6.RELEASE整合Oatuh2实现单点登录](https://github.com/longfeizheng/sso-merryyou)
