package moe.cnkirito.security.oauth2.code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author 徐靖峰[OF2938]
 * company qianmi.com
 * Date 2018-04-25
 */
@SpringBootApplication
public class QQApp {

    public static void main(String[] args) {
        SpringApplication.run(QQApp.class, args);
    }

}
