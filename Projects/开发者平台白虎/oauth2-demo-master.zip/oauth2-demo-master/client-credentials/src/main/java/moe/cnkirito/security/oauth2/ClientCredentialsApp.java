package moe.cnkirito.security.oauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by xujingfeng on 2017/8/7.
 */
@SpringBootApplication
public class ClientCredentialsApp {

    public static void main(String[] args) {
        SpringApplication.run(ClientCredentialsApp.class, args);
    }
}
