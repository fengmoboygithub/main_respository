package com.chentongwe.code;

//import com.chentongwei.security.core.validate.code.ValidateCode;
//import com.chentongwei.security.core.validate.code.ValidateCodeGenerator;
//import org.springframework.stereotype.Component;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * @author chentongwei@bshf360.com 2018-03-27 15:50
 */
//@Component("imageValidateCodeGenerator")
//public class DemoImageCodeGenerator implements ValidateCodeGenerator {
//
//    @Override
//    public ValidateCode generate(ServletWebRequest request) {
//        System.out.println("自己的验证码...");
//        return null;
//    }
//}
