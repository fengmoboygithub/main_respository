/*
package com.chentongwe.web;

import org.springframework.social.connect.Connection;
import org.springframework.social.connect.ConnectionSignUp;
import org.springframework.stereotype.Component;

*/
/**
 * @author chentongwei@bshf360.com 2018-04-03 13:34
 *//*

//@Component
public class DemoConnectionSignUp implements ConnectionSignUp {

    @Override
    public String execute(Connection<?> connection) {
        System.out.println("2222222222222222222222222222222");
        // 根据社交用户信息(connection)，默认创建用户并返回用户唯一标识。
        return connection.getKey().getProviderUserId();
    }
}
*/
