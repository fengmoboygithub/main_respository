package com.chentongwe.code;

//import com.chentongwei.security.core.validate.code.ValidateCode;
//import com.chentongwei.security.core.validate.code.ValidateCodeGenerator;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * @author TongWei.Chen 2018-03-31 19:26:00
 * @Project common-security
 * @Description:
 */
//@Component("geetestValidateCodeGenerator")
//public class DemoGeetestCodeGenerator implements ValidateCodeGenerator {
//    @Override
//    public ValidateCode generate(ServletWebRequest request) {
//        System.out.println("自己的极验证逻辑");
//        return null;
//    }
//}
