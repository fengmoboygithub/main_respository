/*
package com.chentongwe.code;

import com.chentongwei.security.core.validate.sms.SmsCodeSender;
import org.springframework.stereotype.Component;

*/
/**
 * @author chentongwei@bshf360.com 2018-03-28 12:46
 *//*

//@Component
public class DemoSmsCodeSender implements SmsCodeSender {
    @Override
    public void send(String mobile, String code) {
        System.out.println("自己定义的手机号sender" + mobile + "code:" + code);
    }
}
*/
