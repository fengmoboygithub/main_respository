package com.chentongwei.security.browser.enums;

/**
 * 浏览器的url枚举
 *
 * @author chentongwei@bshf360.com 2018-06-04 16:37
 */
public enum BrowserProcessingUrlEnum {
}
