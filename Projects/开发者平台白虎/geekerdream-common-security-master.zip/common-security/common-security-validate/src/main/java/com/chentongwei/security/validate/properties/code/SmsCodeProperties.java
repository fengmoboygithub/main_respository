package com.chentongwei.security.validate.properties.code;

/**
 * 短信验证码基础配置
 *
 * @author chentongwei@bshf360.com 2018-03-28 09:55
 */
public class SmsCodeProperties extends CommonCodeProperties {
}
