/**
 * 
 */
/**
 * Title: package-info
 * Description: 配置文件获取的测试
 * Version:1.0.0  
 * @author pancm
 * @date 2018年1月11日
 */
package com.test.properties;