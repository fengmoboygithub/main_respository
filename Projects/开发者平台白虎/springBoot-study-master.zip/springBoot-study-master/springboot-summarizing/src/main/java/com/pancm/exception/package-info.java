/**
 * 
 */
/**
 * Title: package-info
 * Description: 
 * 异常类处理
 * Version:1.0.0  
 * @author pancm
 * @date 2018年3月21日
 */
package com.pancm.exception;