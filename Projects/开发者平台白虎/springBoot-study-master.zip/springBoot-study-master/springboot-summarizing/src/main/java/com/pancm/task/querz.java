package com.pancm.task;

public class querz {

}
