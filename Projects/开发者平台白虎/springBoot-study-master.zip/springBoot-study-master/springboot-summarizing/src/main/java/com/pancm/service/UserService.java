package com.pancm.service;

import com.pancm.pojo.User;


/**
 * 
* Title: UserService
* Description:用户接口 
* Version:1.0.0  
* @author pancm
* @date 2018年1月9日
 */
public interface UserService extends BaseService<User>{
	
	

}
