/**
* @Title: package-info
* @Description: 
* protobuf相关类
* protobuf使用说明
* 把protoc.exe和User.proto放在E:\protobuf 盘符下
* 然后在dos界面输入:
* protoc.exe --java_out=E:\protobuf User.proto
* 即可生成UserInfo文件
* @Version:1.0.0  
* @author pancm
* @date 2018年7月11日
*/
package com.pancm.protobuf;