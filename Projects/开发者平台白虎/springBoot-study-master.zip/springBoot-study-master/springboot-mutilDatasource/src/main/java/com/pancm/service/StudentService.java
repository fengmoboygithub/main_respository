package com.pancm.service;

import com.pancm.pojo.Student;



/**
 * 
* Title: StudentService
* Description: 
* 学生接口 
* Version:1.0.0  
* @author pancm
* @date 2018年3月19日
 */
public interface StudentService  extends BaseService<Student>{
	
}
