package com.pancm.dao.cluster;

import org.apache.ibatis.annotations.Mapper;

import com.pancm.dao.BaseDao;
import com.pancm.pojo.Student;

/**
 * 
* @Title: StudentDao
* @Description: 
* @Version:1.0.0  
* @author pancm
* @date 2018年4月9日
 */
@Mapper
public interface StudentDao extends BaseDao<Student>{

}
