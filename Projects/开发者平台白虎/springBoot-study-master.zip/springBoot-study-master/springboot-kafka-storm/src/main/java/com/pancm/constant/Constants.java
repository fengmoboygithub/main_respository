/**
 * 
 */
package com.pancm.constant;

/**
* @Title: Constants
* @Description:
* 常量类 
* @Version:1.0.0  
* @author pancm
* @date 2018年5月9日
*/
public class Constants {
	
	public  final static String KAFKA_SPOUT="KAFKA_SPOUT"; 
	public  final static String INSERT_BOLT="INSERT_BOLT"; 
	public  final static String FIELD="insert";
}
