# generationcode
结合mybatis逆向工程生成CURL 控制层 实现层 映射数据库实体bean的注释
