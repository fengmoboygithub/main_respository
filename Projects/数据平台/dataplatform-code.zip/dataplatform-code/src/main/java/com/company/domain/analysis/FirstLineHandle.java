package com.company.domain.analysis;

import com.company.base.handle.Handle;

/**
 * 首行信息处理操作接口
 * @author yangyanchao
 *
 */
public interface FirstLineHandle<T> extends Handle<T>{

}
