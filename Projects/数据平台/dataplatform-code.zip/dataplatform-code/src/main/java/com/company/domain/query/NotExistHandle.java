package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * 判断不存在操作接口
 * @author yangyanchao
 *
 */
public interface NotExistHandle<T> extends Handle<T>{

}
