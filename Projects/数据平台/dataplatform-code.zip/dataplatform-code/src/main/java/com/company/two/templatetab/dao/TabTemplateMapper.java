package com.company.two.templatetab.dao;

import com.company.base.dao.IBaseDao;
import com.company.two.templatetab.model.TabTemplate;
import com.company.two.templatetab.model.TabTemplateExample;
public interface TabTemplateMapper extends IBaseDao<TabTemplate, TabTemplateExample>{

}