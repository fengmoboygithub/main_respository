package com.company.domain.analysis;

import com.company.base.handle.Handle;

/**
 * catch处理操作接口
 * @author yangyanchao
 *
 */
public interface CatchHandle<T> extends Handle<T>{

}
