package com.company.one.handletuple.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.handletuple.model.HandleTupleTmp;
import com.company.one.handletuple.model.HandleTupleTmpExample;
public interface HandleTupleTmpMapper extends IBaseDao<HandleTupleTmp, HandleTupleTmpExample>{

}