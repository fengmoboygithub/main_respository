package com.company.domain.analysis;

import com.company.base.handle.Handle;

/**
 * 普通信息循环处理操作接口
 * @author yangyanchao
 *
 */
public interface PlainLoopHandle<T> extends Handle<T>{
	
}
