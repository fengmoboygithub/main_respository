package com.company.one.handlefile.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.handlefile.model.HandleFileTab;
import com.company.one.handlefile.model.HandleFileTabExample;
public interface HandleFileTabMapper extends IBaseDao<HandleFileTab, HandleFileTabExample>{

}