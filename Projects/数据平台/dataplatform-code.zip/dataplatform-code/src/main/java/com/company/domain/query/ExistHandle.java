package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * 判断存在操作接口
 * @author yangyanchao
 *
 */
public interface ExistHandle<T> extends Handle<T>{

}
