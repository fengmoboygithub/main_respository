package com.company.one.handleplain.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.handleplain.model.HandlePlainTmp;
import com.company.one.handleplain.model.HandlePlainTmpExample;
public interface HandlePlainTmpMapper extends IBaseDao<HandlePlainTmp, HandlePlainTmpExample>{

}