package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * 判断存在循环操作接口
 * @author yangyanchao
 *
 */
public interface LoopHandle<T> extends Handle<T>{

}
