package com.company.domain.analysis;

import com.company.base.handle.Handle;

/**
 * 元组信息结束处理操作接口
 * @author yangyanchao
 *
 */
public interface TupleLoopEndHandle<T> extends Handle<T>{
	
}
