package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * hash判断存在操作接口
 * @author yangyanchao
 *
 */
public interface ExistHashHandle<T> extends Handle<T>{

}
