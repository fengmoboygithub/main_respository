package com.company.domain.analysis;

import com.company.base.handle.Handle;

/**
 * 元组信息循环处理操作接口
 * @author yangyanchao
 *
 */
public interface TupleLoopHandle<T> extends Handle<T>{
	
}
