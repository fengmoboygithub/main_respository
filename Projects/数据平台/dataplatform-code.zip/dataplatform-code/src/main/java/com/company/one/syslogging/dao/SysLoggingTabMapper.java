package com.company.one.syslogging.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.syslogging.model.SysLoggingTab;
import com.company.one.syslogging.model.SysLoggingTabExample;
public interface SysLoggingTabMapper extends IBaseDao<SysLoggingTab, SysLoggingTabExample>{

}