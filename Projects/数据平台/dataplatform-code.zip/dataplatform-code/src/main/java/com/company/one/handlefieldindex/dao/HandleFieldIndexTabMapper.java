package com.company.one.handlefieldindex.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.handlefieldindex.model.HandleFieldIndexTab;
import com.company.one.handlefieldindex.model.HandleFieldIndexTabExample;
public interface HandleFieldIndexTabMapper extends IBaseDao<HandleFieldIndexTab, HandleFieldIndexTabExample>{

}