package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * 第一次操作接口
 * @author yangyanchao
 *
 */
public interface FirstHandle<T> extends Handle<T>{

}
