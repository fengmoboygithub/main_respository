package com.company.one.handledetail.dao;

import com.company.base.dao.IBaseDao;
import com.company.one.handledetail.model.HandleDetailTab;
import com.company.one.handledetail.model.HandleDetailTabExample;
public interface HandleDetailTabMapper extends IBaseDao<HandleDetailTab, HandleDetailTabExample>{

}