package com.company.domain.analysis;

import com.company.base.handle.Handle;

/**
 * 普通信息循环结束处理操作接口
 * @author yangyanchao
 *
 */
public interface PlainLoopEndHandle<T> extends Handle<T>{
	
}
