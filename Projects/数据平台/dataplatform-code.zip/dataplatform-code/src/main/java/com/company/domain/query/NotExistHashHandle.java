package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * hash判断不存在操作接口
 * @author yangyanchao
 *
 */
public interface NotExistHashHandle<T> extends Handle<T>{

}
