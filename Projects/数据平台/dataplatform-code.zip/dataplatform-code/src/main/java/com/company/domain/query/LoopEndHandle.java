package com.company.domain.query;

import com.company.base.handle.Handle;

/**
 * 循环完毕操作接口
 * @author yangyanchao
 *
 */
public interface LoopEndHandle<T> extends Handle<T>{

}
