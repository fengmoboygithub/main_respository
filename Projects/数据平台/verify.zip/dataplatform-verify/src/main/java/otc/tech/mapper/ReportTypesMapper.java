package otc.tech.mapper;

import org.apache.ibatis.annotations.Mapper;

import otc.tech.base.mapper.BaseMapper;
import otc.tech.model.ReportTypes;
@Mapper
public interface ReportTypesMapper extends BaseMapper<ReportTypes>{

}
