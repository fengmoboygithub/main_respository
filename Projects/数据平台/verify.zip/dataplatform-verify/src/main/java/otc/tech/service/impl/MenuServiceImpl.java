package otc.tech.service.impl;

import org.springframework.stereotype.Service;

import otc.tech.base.service.impl.BaseServiceImpl;
import otc.tech.model.Menu;
import otc.tech.service.IMenuService;

@Service
public class MenuServiceImpl extends BaseServiceImpl<Menu> implements IMenuService {
	
}
