package otc.tech.mapper;

import org.apache.ibatis.annotations.Mapper;

import otc.tech.base.mapper.BaseMapper;
import otc.tech.model.Menu;

@Mapper
public interface MenuMapper extends BaseMapper<Menu> {

}
