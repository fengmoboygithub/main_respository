package otc.tech.service;

import otc.tech.base.service.IBaseService;
import otc.tech.model.Menu;

public interface IMenuService extends IBaseService<Menu>{

}
