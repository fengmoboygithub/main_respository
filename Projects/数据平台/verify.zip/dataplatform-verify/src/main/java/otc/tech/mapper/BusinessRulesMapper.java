package otc.tech.mapper;

import org.apache.ibatis.annotations.Mapper;

import otc.tech.base.mapper.BaseMapper;
import otc.tech.model.BusinessRules;
@Mapper
public interface BusinessRulesMapper extends BaseMapper<BusinessRules> {

}
