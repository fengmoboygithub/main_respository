# 项目简介
elasticsearch的demo项目<br/>
博客地址  [https://www.cnblogs.com/shaozm/p/9990914.html](https://www.cnblogs.com/shaozm/p/9990914.html)
<hr/>

数据库数据 在根目录下 news_article.sql文件