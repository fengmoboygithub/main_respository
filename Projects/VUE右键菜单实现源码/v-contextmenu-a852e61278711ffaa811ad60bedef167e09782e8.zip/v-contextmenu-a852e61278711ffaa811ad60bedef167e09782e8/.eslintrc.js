module.exports = {
  extends: 'plugin:vue/recommended',
  rules: {},
}
